import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/isotope.dart';
import '../models/unit.dart';

class DecayRecord {
  final String id;
  final DateTime timestamp;
  final String isotopeId;
  final String isotopeName;
  final String isotopeSymbol;
  final double initialActivity;
  final double resultActivity;
  final String unitLabel;
  final double elapsedHours;
  final double halfLifeHours;

  const DecayRecord({
    required this.id,
    required this.timestamp,
    required this.isotopeId,
    required this.isotopeName,
    required this.isotopeSymbol,
    required this.initialActivity,
    required this.resultActivity,
    required this.unitLabel,
    required this.elapsedHours,
    required this.halfLifeHours,
  });

  double get remainingFraction => resultActivity / initialActivity;
  double get remainingPct => remainingFraction * 100;

  Map<String, dynamic> toJson() => {
        'id': id,
        'timestamp': timestamp.toIso8601String(),
        'isotopeId': isotopeId,
        'isotopeName': isotopeName,
        'isotopeSymbol': isotopeSymbol,
        'initialActivity': initialActivity,
        'resultActivity': resultActivity,
        'unitLabel': unitLabel,
        'elapsedHours': elapsedHours,
        'halfLifeHours': halfLifeHours,
      };

  factory DecayRecord.fromJson(Map<String, dynamic> j) => DecayRecord(
        id: j['id'] as String,
        timestamp: DateTime.parse(j['timestamp'] as String),
        isotopeId: j['isotopeId'] as String,
        isotopeName: j['isotopeName'] as String,
        isotopeSymbol: j['isotopeSymbol'] as String,
        initialActivity: (j['initialActivity'] as num).toDouble(),
        resultActivity: (j['resultActivity'] as num).toDouble(),
        unitLabel: j['unitLabel'] as String,
        elapsedHours: (j['elapsedHours'] as num).toDouble(),
        halfLifeHours: (j['halfLifeHours'] as num).toDouble(),
      );
}

class HistoryService {
  HistoryService._();
  static final instance = HistoryService._();

  static const _key = 'decay_history_v1';
  List<DecayRecord> _cache = [];
  bool _loaded = false;

  Future<void> load() async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    _cache = raw
        .map((s) {
          try {
            return DecayRecord.fromJson(jsonDecode(s) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<DecayRecord>()
        .toList();

    // 30-day auto-cleanup
    final cutoff = DateTime.now().subtract(const Duration(days: 30));
    _cache = _cache.where((r) => r.timestamp.isAfter(cutoff)).toList();
    _loaded = true;
  }

  List<DecayRecord> get records => List.unmodifiable(_cache);

  Future<void> add(DecayRecord record) async {
    await load();
    _cache.insert(0, record);
    await _persist();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      _key,
      _cache.map((r) => jsonEncode(r.toJson())).toList(),
    );
  }

  Future<void> clear() async {
    _cache = [];
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}
