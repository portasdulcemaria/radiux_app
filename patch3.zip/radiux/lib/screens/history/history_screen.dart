import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../../services/history_service.dart';
import '../../models/isotope.dart';
import '../../models/decay_service.dart';
import '../../theme/app_theme.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  String _filterTime = 'hoy';
  String? _filterIsotope; // null = all

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await HistoryService.instance.load();
    if (mounted) setState(() {});
  }

  List<DecayRecord> get _allRecords => HistoryService.instance.records;

  List<DecayRecord> get _todayRecords {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    return _allRecords.where((r) {
      final d = DateTime(r.timestamp.year, r.timestamp.month, r.timestamp.day);
      return d == today;
    }).toList();
  }

  Map<String, _IsotopeStats> get _todayByIsotope {
    final map = <String, _IsotopeStats>{};
    for (final r in _todayRecords) {
      final key = r.isotopeId;
      if (!map.containsKey(key)) {
        map[key] = _IsotopeStats(
          isotopeId: r.isotopeId,
          isotopeName: r.isotopeName,
          isotopeSymbol: r.isotopeSymbol,
          halfLifeHours: r.halfLifeHours,
          unitLabel: r.unitLabel,
        );
      }
      map[key]!.add(r);
    }
    return map;
  }

  List<DecayRecord> get _timeFiltered {
    final now = DateTime.now();
    final todayStart = DateTime(now.year, now.month, now.day);
    switch (_filterTime) {
      case 'hoy':
        return _allRecords
            .where((r) => r.timestamp.isAfter(todayStart))
            .toList();
      case 'ayer':
        final yesterdayStart =
            todayStart.subtract(const Duration(days: 1));
        return _allRecords
            .where((r) =>
                r.timestamp.isAfter(yesterdayStart) &&
                r.timestamp.isBefore(todayStart))
            .toList();
      case 'semana':
        final weekStart =
            todayStart.subtract(const Duration(days: 6));
        return _allRecords.where((r) => r.timestamp.isAfter(weekStart)).toList();
      default:
        return _allRecords;
    }
  }

  List<DecayRecord> get _filtered {
    var base = _timeFiltered;
    if (_filterIsotope != null) {
      base = base.where((r) => r.isotopeId == _filterIsotope).toList();
    }
    return base;
  }

  List<String> get _availableIsotopes {
    final ids = _timeFiltered.map((r) => r.isotopeId).toSet().toList();
    return ids;
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final stats = _todayByIsotope;
    final filtered = _filtered;
    final isotopes = _availableIsotopes;

    return RefreshIndicator(
      onRefresh: _load,
      color: AppColors.primary,
      backgroundColor: AppColors.surface,
      child: CustomScrollView(
        physics: const BouncingScrollPhysics(
            parent: AlwaysScrollableScrollPhysics()),
        slivers: [
          // ── TURNO DE HOY ─────────────────────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _SectionHeader(
                    title: 'TURNO DE HOY',
                    subtitle: DateFormat("EEEE, d 'de' MMMM", 'es_AR')
                        .format(DateTime.now()),
                  ),
                  const SizedBox(height: 12),
                  if (stats.isEmpty)
                    _EmptyTurno()
                  else
                    ...stats.values.toList().asMap().entries.map((e) =>
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: _IsotopeCard(stats: e.value)
                              .animate()
                              .fadeIn(delay: (e.key * 80).ms, duration: 350.ms)
                              .slideY(begin: 0.15, end: 0),
                        )),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),

          // ── REGISTROS header + chips ──────────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const _SectionHeader(title: 'REGISTROS'),
                  const SizedBox(height: 10),
                  // Time chips
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _Chip(
                          label: 'Hoy',
                          selected: _filterTime == 'hoy',
                          onTap: () => setState(() {
                            _filterTime = 'hoy';
                            _filterIsotope = null;
                          }),
                        ),
                        const SizedBox(width: 8),
                        _Chip(
                          label: 'Ayer',
                          selected: _filterTime == 'ayer',
                          onTap: () => setState(() {
                            _filterTime = 'ayer';
                            _filterIsotope = null;
                          }),
                        ),
                        const SizedBox(width: 8),
                        _Chip(
                          label: '7 días',
                          selected: _filterTime == 'semana',
                          onTap: () => setState(() {
                            _filterTime = 'semana';
                            _filterIsotope = null;
                          }),
                        ),
                      ],
                    ),
                  ),
                  if (isotopes.length > 1) ...[
                    const SizedBox(height: 8),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _Chip(
                            label: 'Todos',
                            selected: _filterIsotope == null,
                            onTap: () =>
                                setState(() => _filterIsotope = null),
                            color: AppColors.textSecondary,
                          ),
                          ...isotopes.map((id) {
                            final iso = kIsotopes.firstWhere((i) => i.id == id,
                                orElse: () => kIsotopes.first);
                            return Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: _Chip(
                                label: iso.symbol.split('\n').join(''),
                                selected: _filterIsotope == id,
                                onTap: () =>
                                    setState(() => _filterIsotope = id),
                                color: iso.color,
                              ),
                            );
                          }),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),

          // ── Record list ───────────────────────────────────────────────
          if (filtered.isEmpty)
            SliverToBoxAdapter(child: _EmptyRecords(filter: _filterTime))
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, i) {
                  final record = filtered[i];
                  // Show day separator if this record is a new day
                  final showDay = i == 0 ||
                      !_sameDay(filtered[i - 1].timestamp, record.timestamp);
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (showDay)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 6),
                          child: Text(
                            _dayLabel(record.timestamp),
                            style: Theme.of(context)
                                .textTheme
                                .labelSmall
                                ?.copyWith(
                                    color: AppColors.textSecondary,
                                    letterSpacing: 0.8),
                          ),
                        ),
                      Padding(
                        padding:
                            const EdgeInsets.fromLTRB(16, 0, 16, 8),
                        child: _RecordRow(record: record)
                            .animate()
                            .fadeIn(
                                delay: (i * 40).ms, duration: 300.ms),
                      ),
                    ],
                  );
                },
                childCount: filtered.length,
              ),
            ),

          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
    );
  }

  bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  String _dayLabel(DateTime dt) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final d = DateTime(dt.year, dt.month, dt.day);
    if (d == today) return 'HOY';
    if (d == today.subtract(const Duration(days: 1))) return 'AYER';
    return DateFormat('EEEE d MMM', 'es_AR').format(dt).toUpperCase();
  }
}

// ── Data model ────────────────────────────────────────────────────────────────

class _IsotopeStats {
  final String isotopeId;
  final String isotopeName;
  final String isotopeSymbol;
  final double halfLifeHours;
  final String unitLabel;
  final List<DecayRecord> records = [];

  _IsotopeStats({
    required this.isotopeId,
    required this.isotopeName,
    required this.isotopeSymbol,
    required this.halfLifeHours,
    required this.unitLabel,
  });

  void add(DecayRecord r) => records.add(r);

  int get count => records.length;

  double get latestResult =>
      records.isEmpty ? 0 : records.first.resultActivity;

  double get avgRemaining =>
      records.isEmpty
          ? 0
          : records.map((r) => r.remainingPct).reduce((a, b) => a + b) /
              records.length;

  Color get marginColor {
    if (avgRemaining > 60) return AppColors.success;
    if (avgRemaining > 20) return AppColors.warning;
    return AppColors.error;
  }

  String get marginLabel {
    if (avgRemaining > 60) return 'Buen margen';
    if (avgRemaining > 20) return 'Margen medio';
    return 'Bajo margen';
  }

  Isotope get isotope => kIsotopes.firstWhere(
        (i) => i.id == isotopeId,
        orElse: () => kIsotopes.first,
      );
}

// ── Widgets ───────────────────────────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;

  const _SectionHeader({required this.title, this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: AppColors.textSecondary,
                letterSpacing: 1.2,
                fontWeight: FontWeight.w700,
              ),
        ),
        if (subtitle != null) ...[
          const SizedBox(height: 2),
          Text(
            subtitle!,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppColors.textSecondary.withOpacity(0.7),
                ),
          ),
        ],
      ],
    );
  }
}

class _IsotopeCard extends StatelessWidget {
  final _IsotopeStats stats;
  const _IsotopeCard({required this.stats});

  @override
  Widget build(BuildContext context) {
    final iso = stats.isotope;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Isotope pill
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: iso.color.withOpacity(0.12),
                  border: Border.all(color: iso.color.withOpacity(0.3)),
                ),
                alignment: Alignment.center,
                child: Text(
                  iso.symbol,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: iso.color,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    height: 1.2,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      stats.isotopeName,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    Text(
                      '${stats.count} cálculo${stats.count != 1 ? 's' : ''} hoy',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              // Margin badge
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: stats.marginColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: stats.marginColor.withOpacity(0.3)),
                ),
                child: Text(
                  stats.marginLabel,
                  style: TextStyle(
                    color: stats.marginColor == AppColors.error
                        ? AppColors.errorText
                        : stats.marginColor,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Progress bar: avg remaining
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Actividad promedio restante',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: AppColors.textSecondary,
                        ),
                  ),
                  Text(
                    '${stats.avgRemaining.toStringAsFixed(1)}%',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: stats.marginColor == AppColors.error
                              ? AppColors.errorText
                              : stats.marginColor,
                          fontWeight: FontWeight.w700,
                        ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: stats.avgRemaining / 100,
                  backgroundColor: AppColors.cardHover,
                  valueColor:
                      AlwaysStoppedAnimation(stats.marginColor),
                  minHeight: 6,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Last result
          Row(
            children: [
              const Icon(Icons.schedule_rounded,
                  size: 13, color: AppColors.textSecondary),
              const SizedBox(width: 4),
              Text(
                'Último: ${DecayService.formatActivity(stats.latestResult)} ${stats.unitLabel}',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: AppColors.textSecondary,
                    ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RecordRow extends StatelessWidget {
  final DecayRecord record;
  const _RecordRow({required this.record});

  @override
  Widget build(BuildContext context) {
    final iso = kIsotopes.firstWhere((i) => i.id == record.isotopeId,
        orElse: () => kIsotopes.first);
    final timeFmt = DateFormat('HH:mm');
    final pct = record.remainingPct.toStringAsFixed(1);

    Color pctColor = AppColors.success;
    if (record.remainingPct < 20) pctColor = AppColors.error;
    else if (record.remainingPct < 60) pctColor = AppColors.warning;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          // Isotope color dot
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: iso.color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: iso.color.withOpacity(0.3)),
            ),
            alignment: Alignment.center,
            child: Text(
              iso.symbol.split('\n').first,
              style: TextStyle(
                color: iso.color,
                fontSize: 9,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  record.isotopeName,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  '${DecayService.formatActivity(record.initialActivity)} → ${DecayService.formatActivity(record.resultActivity)} ${record.unitLabel}',
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 11,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                timeFmt.format(record.timestamp),
                style: const TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 11,
                ),
              ),
              Text(
                '$pct%',
                style: TextStyle(
                  color: pctColor == AppColors.error
                      ? AppColors.errorText
                      : pctColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Color? color;

  const _Chip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.primary;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? c.withOpacity(0.12) : AppColors.card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? c.withOpacity(0.5) : AppColors.border,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected
                ? (c == AppColors.error ? AppColors.errorText : c)
                : AppColors.textSecondary,
            fontSize: 12,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _EmptyTurno extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          const Icon(Icons.science_outlined,
              color: AppColors.textSecondary, size: 20),
          const SizedBox(width: 12),
          Text(
            'Sin cálculos registrados hoy',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.textSecondary,
                ),
          ),
        ],
      ),
    );
  }
}

class _EmptyRecords extends StatelessWidget {
  final String filter;
  const _EmptyRecords({required this.filter});

  @override
  Widget build(BuildContext context) {
    final label = filter == 'hoy'
        ? 'hoy'
        : filter == 'ayer'
            ? 'ayer'
            : 'los últimos 7 días';
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 40),
      child: Center(
        child: Text(
          'No hay registros de $label',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: AppColors.textSecondary.withOpacity(0.6),
              ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
