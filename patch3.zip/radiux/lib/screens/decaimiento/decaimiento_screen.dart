import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import 'dart:async';
import 'dart:math' as math;
import '../../models/isotope.dart';
import '../../models/unit.dart';
import '../../models/decay_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/glass_card.dart';
import '../../services/sound_service.dart';
import '../../services/history_service.dart';

class DecaimientoScreen extends StatefulWidget {
  const DecaimientoScreen({super.key});

  @override
  State<DecaimientoScreen> createState() => _DecaimientoScreenState();
}

class _DecaimientoScreenState extends State<DecaimientoScreen>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  // State
  final _controller = TextEditingController();
  final _focusNode = FocusNode();

  RadioUnit _unit = kUnits[4]; // mCi default
  Isotope _isotope = kIsotopes.first; // Tc99m
  DateTime _referenceDate = DateTime.now();
  double _addedHours = 0;
  int? _selectedQuickIdx;

  double? _result;
  String? _errorText;
  bool _isCalculating = false;
  Timer? _debounce;

  // Stepper state
  int _activeStep = 0; // 0=activity, 1=isotope, 2=time
  bool _isotopeConfirmed = false;

  DateTime get _targetDate =>
      _referenceDate.add(Duration(minutes: (_addedHours * 60).round()));

  double? get _initialActivity {
    final text = _controller.text.replaceAll(',', '.');
    return double.tryParse(text);
  }

  bool get _step0Done =>
      _controller.text.isNotEmpty &&
      _initialActivity != null &&
      _initialActivity! > 0;

  bool get _step1Done => _isotopeConfirmed;

  bool get _step2Done => _addedHours > 0;

  bool get _canCalculate => _step0Done && _step1Done && _step2Done;

  List<_QuickTimeOption> get _quickOptions => [
        _QuickTimeOption(label: '+1h', hours: 1),
        _QuickTimeOption(label: '+6h', hours: 6),
        _QuickTimeOption(label: '+12h', hours: 12),
        _QuickTimeOption(label: '+24h', hours: 24),
        _QuickTimeOption(
          label: '+T½',
          hours: _isotope.halfLifeHours,
          isHalfLife: true,
        ),
      ];

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onInputChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onInputChanged() {
    setState(() {
      _errorText = null;
      _result = null;
    });
    // Auto-advance to isotope step when activity is valid
    if (_step0Done && _activeStep == 0) {
      Future.delayed(const Duration(milliseconds: 300), () {
        if (mounted && _step0Done && _activeStep == 0) {
          setState(() => _activeStep = 1);
          _focusNode.unfocus();
        }
      });
    }
  }

  void _confirmIsotope(Isotope iso) {
    HapticFeedback.selectionClick();
    SoundService.instance.select();
    setState(() {
      _isotope = iso;
      _isotopeConfirmed = true;
      _result = null;
      if (_activeStep == 1) _activeStep = 2;
    });
  }

  void _selectQuickTime(int idx) {
    HapticFeedback.selectionClick();
    SoundService.instance.tick();
    setState(() {
      if (_selectedQuickIdx == idx) {
        _selectedQuickIdx = null;
        _addedHours = 0;
        _result = null;
      } else {
        _selectedQuickIdx = idx;
        _addedHours = _quickOptions[idx].hours;
        _result = null;
      }
    });
    if (_canCalculate) {
      _debounce?.cancel();
      _debounce = Timer(const Duration(milliseconds: 400), _calculate);
    }
  }

  Future<void> _pickDateTime() async {
    final result = await showModalBottomSheet<DateTime>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _DateTimePickerSheet(initial: _referenceDate),
    );
    if (result == null) return;
    setState(() {
      _referenceDate = result;
      _result = null;
    });
    HapticFeedback.lightImpact();
  }

  Future<void> _calculate() async {
    final a0 = _initialActivity;
    if (a0 == null || a0 <= 0) {
      setState(() => _errorText = 'Ingresá un valor de actividad positivo');
      HapticFeedback.mediumImpact();
      SoundService.instance.error();
      return;
    }
    if (_addedHours <= 0) {
      setState(() => _errorText = 'Seleccioná un tiempo transcurrido');
      HapticFeedback.mediumImpact();
      SoundService.instance.error();
      return;
    }

    setState(() => _isCalculating = true);
    await Future.delayed(const Duration(milliseconds: 150));

    final result = DecayService.decay(
      initialActivity: a0,
      halfLifeHours: _isotope.halfLifeHours,
      elapsedHours: _addedHours,
    );

    setState(() {
      _result = result;
      _isCalculating = false;
      _errorText = null;
    });

    // Save to history
    await HistoryService.instance.add(DecayRecord(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      timestamp: DateTime.now(),
      isotopeId: _isotope.id,
      isotopeName: _isotope.name,
      isotopeSymbol: _isotope.symbol,
      initialActivity: a0,
      resultActivity: result,
      unitLabel: _unit.label,
      elapsedHours: _addedHours,
      halfLifeHours: _isotope.halfLifeHours,
    ));

    // Haptic + sonido: resultado
    HapticFeedback.mediumImpact();
    SoundService.instance.success();
    // Show dramatic result reveal sheet
    if (mounted) {
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        builder: (_) => _ResultRevealSheet(
          result: result,
          initialActivity: a0,
          unit: _unit,
          isotope: _isotope,
          elapsedHours: _addedHours,
        ),
      );
    }
    // Landing haptic when ring completes (900ms)
    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) HapticFeedback.heavyImpact();
    });
  }

  void _reset() {
    HapticFeedback.mediumImpact();
    setState(() {
      _controller.clear();
      _addedHours = 0;
      _selectedQuickIdx = null;
      _result = null;
      _errorText = null;
      _referenceDate = DateTime.now();
      _isotopeConfirmed = false;
      _activeStep = 0;
      _isotope = kIsotopes.first;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _focusNode.requestFocus();
    });
  }

  void _goToStep(int step) {
    if (step == 0 || (step == 1 && _step0Done) || (step == 2 && _step1Done)) {
      setState(() => _activeStep = step);
      if (step == 0) _focusNode.requestFocus();
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Stack(
      children: [
        GestureDetector(
          onTap: () => _focusNode.unfocus(),
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 120),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Result ───────────────────────────────────────────────
                if (_result != null && _initialActivity != null) ...[
                  _DecayResultCard(
                    initialActivity: _initialActivity!,
                    result: _result!,
                    unit: _unit,
                    isotope: _isotope,
                    elapsedHours: _addedHours,
                  )
                      .animate()
                      .fadeIn(duration: 500.ms)
                      .slideY(begin: 0.2, end: 0)
                      .scale(begin: const Offset(0.96, 0.96)),
                  const SizedBox(height: 10),
                  Center(
                    child: GestureDetector(
                      onTap: _reset,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
                        child: Text(
                          'Nuevo cálculo',
                          style: Theme.of(context).textTheme.labelMedium?.copyWith(
                              color: const Color(0xFF7C5CFC).withOpacity(0.6),
                              decoration: TextDecoration.underline,
                              decorationColor: const Color(0xFF7C5CFC).withOpacity(0.4)),
                        ),
                      ),
                    ),
                  ).animate().fadeIn(delay: 200.ms),
                  const SizedBox(height: 20),
                ],

                // ── Sección 1: Actividad inicial (siempre visible) ────────
                Text('Actividad inicial',
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                        color: AppColors.textSecondary,
                        letterSpacing: 0.3,
                        fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                _ActivityInputRow(
                  controller: _controller,
                  focusNode: _focusNode,
                  unit: _unit,
                  hasError: _errorText != null && !_step0Done,
                  onUnitTap: _showUnitPicker,
                ).animate().fadeIn(duration: 300.ms),
                if (_errorText != null && !_step0Done) ...[
                  const SizedBox(height: 6),
                  _ErrorHint(text: _errorText!).animate().fadeIn(),
                ],

                // ── Sección 2: Isótopo (aparece cuando actividad es válida) ─
                AnimatedSize(
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeOut,
                  child: _step0Done
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 20),
                            Text('Isótopo',
                                style: Theme.of(context)
                                    .textTheme
                                    .labelMedium
                                    ?.copyWith(
                                        color: AppColors.textSecondary,
                                        letterSpacing: 0.3,
                                        fontWeight: FontWeight.w600)),
                            const SizedBox(height: 8),
                            GestureDetector(
                              onTap: _showIsotopePicker,
                              child: Container(
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color: AppColors.card,
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: _step1Done
                                        ? AppColors.success.withOpacity(0.5)
                                        : AppColors.border,
                                    width: _step1Done ? 1.5 : 1,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: _step1Done
                                          ? AppColors.success.withOpacity(0.08)
                                          : Colors.black.withOpacity(0.15),
                                      blurRadius: _step1Done ? 16 : 8,
                                      offset: const Offset(0, 2),
                                    )
                                  ],
                                ),
                                child: Row(
                                  children: [
                                    _IsotopePill(
                                        isotope: _isotope, size: 'large'),
                                    const SizedBox(width: 14),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(_isotope.name,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .titleMedium),
                                          Text(_isotope.halfLifeDisplay,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodySmall),
                                          Text(_isotope.category,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .labelSmall
                                                  ?.copyWith(
                                                      color: _isotope.color
                                                          .withOpacity(0.8))),
                                        ],
                                      ),
                                    ),
                                    if (_step1Done)
                                      const Icon(Icons.check_circle_rounded,
                                          color: AppColors.success, size: 20)
                                    else
                                      const Icon(Icons.chevron_right_rounded,
                                          color: AppColors.textSecondary),
                                  ],
                                ),
                              ),
                            ),
                            if (!_step1Done) ...[
                              const SizedBox(height: 10),
                              GestureDetector(
                                onTap: () => _confirmIsotope(_isotope),
                                child: Container(
                                  width: double.infinity,
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 13),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [Color(0xFF7C5CFC), Color(0xFFAA6FF0)],
                                    ),
                                    borderRadius: BorderRadius.circular(14),
                                    boxShadow: [
                                      BoxShadow(
                                        color: const Color(0xFF7C5CFC).withOpacity(0.35),
                                        blurRadius: 16,
                                        offset: const Offset(0, 6),
                                      )
                                    ],
                                  ),
                                  alignment: Alignment.center,
                                  child: Text('Confirmar isótopo',
                                      style: Theme.of(context)
                                          .textTheme
                                          .labelLarge
                                          ?.copyWith(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w700)),
                                ),
                              ),
                            ],
                          ],
                        )
                      : const SizedBox.shrink(),
                ),

                // ── Sección 3: Tiempo (aparece cuando isótopo confirmado) ──
                AnimatedSize(
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeOut,
                  child: _step1Done
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 20),
                            Row(
                              children: [
                                Expanded(
                                  child: Text('Fecha inicial',
                                      style: Theme.of(context)
                                          .textTheme
                                          .labelMedium
                                          ?.copyWith(
                                              color:
                                                  AppColors.textSecondary)),
                                ),
                                GestureDetector(
                                  onTap: _pickDateTime,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 12, vertical: 6),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF7C5CFC).withOpacity(0.08),
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                          color: const Color(0xFF7C5CFC).withOpacity(0.3)),
                                    ),
                                    child: Row(
                                      children: [
                                        const Icon(
                                            Icons.edit_calendar_rounded,
                                            size: 14,
                                            color: AppColors.primaryText),
                                        const SizedBox(width: 6),
                                        Text('Modificar',
                                            style: Theme.of(context)
                                                .textTheme
                                                .labelSmall
                                                ?.copyWith(
                                                    color: AppColors.primaryText,
                                                    fontWeight:
                                                        FontWeight.w600)),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            _DateTimeCard(dateTime: _referenceDate),
                            const SizedBox(height: 20),
                            Text('Tiempo transcurrido',
                                style: Theme.of(context)
                                    .textTheme
                                    .labelMedium
                                    ?.copyWith(
                                        color: AppColors.textSecondary,
                                        letterSpacing: 0.3,
                                        fontWeight: FontWeight.w600)),
                            const SizedBox(height: 10),
                            _QuickTimeRow(
                              options: _quickOptions,
                              selectedIdx: _selectedQuickIdx,
                              onSelect: _selectQuickTime,
                            ),
                            if (_selectedQuickIdx != null) ...[
                              const SizedBox(height: 10),
                              _TargetDateCard(
                                targetDate: _targetDate,
                                addedHours: _addedHours,
                                isotope: _isotope,
                              )
                                  .animate()
                                  .fadeIn(duration: 300.ms)
                                  .slideY(begin: 0.1, end: 0),
                            ],
                          ],
                        )
                      : const SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ),

        // ── Sticky CTA ───────────────────────────────────────────────────
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: _CalculateFooter(
            canCalculate: _canCalculate,
            isCalculating: _isCalculating,
            hasResult: _result != null,
            onTap: _calculate,
          ),
        ),
      ],
    );
  }

  void _showUnitPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        final maxH = MediaQuery.of(ctx).size.height * 0.6;
        return ConstrainedBox(
          constraints: BoxConstraints(maxHeight: maxH),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                        child: Container(
                            width: 36,
                            height: 4,
                            decoration: BoxDecoration(
                                color: AppColors.border,
                                borderRadius: BorderRadius.circular(2)))),
                    const SizedBox(height: 16),
                    Text('Unidad de actividad',
                        style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
                  children: kUnits.map((u) => ListTile(
                        dense: true,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        tileColor: u.id == _unit.id
                            ? AppColors.primaryGlow
                            : Colors.transparent,
                        title: Text('${u.label} — ${u.fullName}',
                            style: TextStyle(
                                color: u.id == _unit.id
                                    ? AppColors.primary
                                    : AppColors.textPrimary)),
                        trailing: u.id == _unit.id
                            ? const Icon(Icons.check_circle_rounded,
                                color: AppColors.primary, size: 18)
                            : null,
                        onTap: () {
                          setState(() {
                            _unit = u;
                            _result = null;
                          });
                          Navigator.pop(context);
                        },
                      )).toList(),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showIsotopePicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        minChildSize: 0.4,
        maxChildSize: 0.9,
        expand: false,
        builder: (_, scrollCtrl) => _IsotopePickerSheet(
          selected: _isotope,
          scrollController: scrollCtrl,
          onSelect: (iso) {
            Navigator.pop(context);
            _confirmIsotope(iso);
          },
        ),
      ),
    );
  }
}

// ── StepCard ──────────────────────────────────────────────────────────────────

class _StepCard extends StatelessWidget {
  final int index;
  final String title;
  final bool isDone;
  final bool isActive;
  final bool isLocked;
  final String? summary;
  final VoidCallback onHeaderTap;
  final Widget child;

  const _StepCard({
    required this.index,
    required this.title,
    required this.isDone,
    required this.isActive,
    required this.isLocked,
    required this.onHeaderTap,
    required this.child,
    this.summary,
  });

  @override
  Widget build(BuildContext context) {
    final Color borderColor = isActive
        ? AppColors.primary
        : isDone
            ? AppColors.success.withOpacity(0.4)
            : AppColors.border;

    final Color numberBg = isActive
        ? AppColors.primary
        : isDone
            ? AppColors.success
            : AppColors.card;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: isActive ? 1.5 : 1),
        boxShadow: isActive
            ? [BoxShadow(color: AppColors.primaryGlow, blurRadius: 12)]
            : null,
      ),
      child: Column(
        children: [
          // Header
          GestureDetector(
            onTap: isLocked ? null : onHeaderTap,
            behavior: HitTestBehavior.opaque,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
              child: Row(
                children: [
                  // Step number / check
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: numberBg,
                      shape: BoxShape.circle,
                      border: isLocked
                          ? Border.all(color: AppColors.border)
                          : null,
                    ),
                    alignment: Alignment.center,
                    child: isDone
                        ? const Icon(Icons.check_rounded,
                            color: Colors.white, size: 16)
                        : Text(
                            '${index + 1}',
                            style: TextStyle(
                              color: isActive
                                  ? Colors.white
                                  : AppColors.textDisabled,
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                            color: isLocked
                                ? AppColors.textDisabled
                                : AppColors.textPrimary,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        if (summary != null && !isActive)
                          Text(
                            summary!,
                            style: const TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 13,
                            ),
                          ),
                      ],
                    ),
                  ),
                  if (isDone && !isActive)
                    const Icon(Icons.edit_rounded,
                        color: AppColors.textDisabled, size: 16),
                  if (isLocked)
                    const Icon(Icons.lock_rounded,
                        color: AppColors.textDisabled, size: 16),
                ],
              ),
            ),
          ),

          // Body (animated)
          AnimatedSize(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeInOut,
            child: isActive
                ? Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    child: child,
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}

// ── Supporting widgets ────────────────────────────────────────────────────────

class _ActivityInputRow extends StatefulWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final RadioUnit unit;
  final bool hasError;
  final VoidCallback onUnitTap;

  const _ActivityInputRow({
    required this.controller,
    required this.focusNode,
    required this.unit,
    required this.hasError,
    required this.onUnitTap,
  });

  @override
  State<_ActivityInputRow> createState() => _ActivityInputRowState();
}

class _ActivityInputRowState extends State<_ActivityInputRow> {
  bool _isFocused = false;

  @override
  void initState() {
    super.initState();
    widget.focusNode.addListener(_onFocusChange);
  }

  @override
  void dispose() {
    widget.focusNode.removeListener(_onFocusChange);
    super.dispose();
  }

  void _onFocusChange() {
    setState(() => _isFocused = widget.focusNode.hasFocus);
  }

  @override
  Widget build(BuildContext context) {
    final borderColor = widget.hasError
        ? AppColors.error.withOpacity(0.7)
        : _isFocused
            ? AppColors.primary.withOpacity(0.6)
            : AppColors.border;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOut,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _isFocused
              ? const Color(0xFF7C5CFC).withOpacity(0.6)
              : widget.hasError
                  ? AppColors.error.withOpacity(0.6)
                  : AppColors.border,
          width: _isFocused || widget.hasError ? 1.5 : 1,
        ),
        color: AppColors.card,
        boxShadow: widget.hasError
            ? [BoxShadow(color: AppColors.errorGlow, blurRadius: 12)]
            : _isFocused
                ? [
                    BoxShadow(
                      color: const Color(0xFF7C5CFC).withOpacity(0.2),
                      blurRadius: 20,
                      spreadRadius: 0,
                    )
                  ]
                : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    )
                  ],
      ),
      child: Row(
        children: [
          // Mirror spacer so the text field centers optically within the full card
          const SizedBox(width: 78),
          Expanded(
            child: TextField(
              controller: widget.controller,
              focusNode: widget.focusNode,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[\d.,]'))
              ],
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 44,
                fontWeight: FontWeight.w700,
                letterSpacing: -1,
              ),
              decoration: const InputDecoration(
                hintText: '',
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                filled: false,
              ),
            ),
          ),
          GestureDetector(
            onTap: widget.onUnitTap,
            child: Container(
              margin: const EdgeInsets.all(8),
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.cardHover,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  Text(widget.unit.label,
                      style: const TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 15,
                          fontWeight: FontWeight.w600)),
                  const SizedBox(width: 4),
                  const Icon(Icons.expand_more_rounded,
                      color: AppColors.textSecondary, size: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorHint extends StatelessWidget {
  final String text;
  const _ErrorHint({required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Icon(Icons.warning_amber_rounded,
            size: 14, color: AppColors.error),
        const SizedBox(width: 6),
        Expanded(
            child: Text(text,
                style: Theme.of(context)
                    .textTheme
                    .labelSmall
                    ?.copyWith(color: AppColors.error))),
      ],
    );
  }
}

class _IsotopePill extends StatelessWidget {
  final Isotope isotope;
  final String size;

  const _IsotopePill({required this.isotope, this.size = 'medium'});

  @override
  Widget build(BuildContext context) {
    final double w = size == 'large' ? 52 : 44;
    final double h = size == 'large' ? 52 : 44;
    final double fs = size == 'large' ? 11 : 9;

    return Container(
      width: w,
      height: h,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: isotope.color.withOpacity(0.12),
        border: Border.all(color: isotope.color.withOpacity(0.3)),
      ),
      alignment: Alignment.center,
      child: Text(
        isotope.symbol,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: isotope.color,
          fontSize: fs,
          fontWeight: FontWeight.w700,
          height: 1.2,
        ),
      ),
    );
  }
}

class _DateTimeCard extends StatelessWidget {
  final DateTime dateTime;

  const _DateTimeCard({required this.dateTime});

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat("EEE, d MMM y, HH:mm", 'es_AR');
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Text(
        fmt.format(dateTime),
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: AppColors.textPrimary,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
        textAlign: TextAlign.center,
      ),
    );
  }
}

class _QuickTimeRow extends StatefulWidget {
  final List<_QuickTimeOption> options;
  final int? selectedIdx;
  final ValueChanged<int> onSelect;

  const _QuickTimeRow({
    required this.options,
    required this.selectedIdx,
    required this.onSelect,
  });

  @override
  State<_QuickTimeRow> createState() => _QuickTimeRowState();
}

class _QuickTimeRowState extends State<_QuickTimeRow> {
  int? _pressedIdx;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: widget.options.asMap().entries.map((e) {
        final idx = e.key;
        final opt = e.value;
        final isSelected = widget.selectedIdx == idx;
        final isPressed = _pressedIdx == idx;

        return Expanded(
          child: GestureDetector(
            onTapDown: (_) => setState(() => _pressedIdx = idx),
            onTapUp: (_) {
              setState(() => _pressedIdx = null);
              widget.onSelect(idx);
            },
            onTapCancel: () => setState(() => _pressedIdx = null),
            child: AnimatedScale(
              scale: isPressed ? 0.91 : 1.0,
              duration: const Duration(milliseconds: 100),
              curve: Curves.easeOut,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOutBack,
                margin: EdgeInsets.only(
                    right: idx < widget.options.length - 1 ? 6 : 0),
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppColors.primary.withOpacity(0.10)
                      : AppColors.card,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected
                        ? AppColors.primary.withOpacity(0.5)
                        : AppColors.border,
                    width: isSelected ? 1.5 : 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.20),
                        blurRadius: 6,
                        offset: const Offset(0, 2))
                  ],
                ),
                alignment: Alignment.center,
                child: Text(
                  opt.label,
                  style: TextStyle(
                    color: isSelected
                        ? AppColors.primaryText
                        : AppColors.textSecondary,
                    fontSize: 13,
                    fontWeight:
                        isSelected ? FontWeight.w700 : FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _TargetDateCard extends StatelessWidget {
  final DateTime targetDate;
  final double addedHours;
  final Isotope isotope;

  const _TargetDateCard({
    required this.targetDate,
    required this.addedHours,
    required this.isotope,
  });

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat("EEE, d MMM y, HH:mm", 'es_AR');
    final fraction =
        math.pow(2, -addedHours / isotope.halfLifeHours).toDouble();
    final pct = (fraction * 100).toStringAsFixed(1);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        border: Border(
          left: const BorderSide(color: AppColors.primary, width: 2),
          top: BorderSide(color: AppColors.border),
          right: BorderSide(color: AppColors.border),
          bottom: BorderSide(color: AppColors.border),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.20),
            blurRadius: 8,
            offset: const Offset(0, 2),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            fmt.format(targetDate),
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(color: AppColors.primaryText),
          ),
          const SizedBox(height: 2),
          Row(
            children: [
              Text(
                'Calculada automáticamente · ',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: AppColors.textSecondary),
              ),
              Text(
                '$pct% restante',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: AppColors.primaryText,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DecayResultCard extends StatefulWidget {
  final double initialActivity;
  final double result;
  final RadioUnit unit;
  final Isotope isotope;
  final double elapsedHours;

  const _DecayResultCard({
    required this.initialActivity,
    required this.result,
    required this.unit,
    required this.isotope,
    required this.elapsedHours,
  });

  @override
  State<_DecayResultCard> createState() => _DecayResultCardState();
}

class _DecayResultCardState extends State<_DecayResultCard>
    with TickerProviderStateMixin {
  bool _copied = false;
  late final AnimationController _shimmerCtrl;

  @override
  void initState() {
    super.initState();
    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1300),
    )..forward();
  }

  @override
  void dispose() {
    _shimmerCtrl.dispose();
    super.dispose();
  }

  void _copy(BuildContext ctx) async {
    HapticFeedback.lightImpact();
    final text =
        '${DecayService.formatActivity(widget.result)} ${widget.unit.label}';
    await Clipboard.setData(ClipboardData(text: text));
    setState(() => _copied = true);
    await Future.delayed(const Duration(milliseconds: 1800));
    if (mounted) setState(() => _copied = false);
  }

  @override
  Widget build(BuildContext context) {
    final fraction = widget.result / widget.initialActivity;
    final pct = (fraction * 100).toStringAsFixed(2);
    final halfLives =
        (widget.elapsedHours / widget.isotope.halfLifeHours).toStringAsFixed(2);

    return GlassCard(
      hasBorderGlow: true,
      glowColor: AppColors.primary,
      isActive: true,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Header ───────────────────────────────────────────────
          Row(
            children: [
              _IsotopePill(isotope: widget.isotope),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Actividad residual',
                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                            color: AppColors.primary.withOpacity(0.8),
                            letterSpacing: 0.4,
                          ),
                    ),
                    Text(widget.isotope.name,
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
              // Copy button with checkmark feedback
              GestureDetector(
                onTap: () => _copy(context),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _copied
                        ? AppColors.success.withOpacity(0.12)
                        : AppColors.card,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: _copied
                          ? AppColors.success.withOpacity(0.4)
                          : AppColors.border,
                    ),
                  ),
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: _copied
                        ? const Icon(Icons.check_rounded,
                            key: ValueKey('check'),
                            size: 16,
                            color: AppColors.success)
                        : const Icon(Icons.copy_rounded,
                            key: ValueKey('copy'),
                            size: 16,
                            color: AppColors.textSecondary),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // ── Animated result number with shimmer ───────────────────
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.0, end: widget.result),
            duration: const Duration(milliseconds: 1100),
            curve: Curves.easeOutCubic,
            builder: (_, value, __) => Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Expanded(
                  child: AnimatedBuilder(
                    animation: _shimmerCtrl,
                    builder: (_, child) {
                      final t = _shimmerCtrl.value;
                      // sweep from -0.4 to 1.4 so light enters and exits fully
                      final pos = t * 1.8 - 0.4;
                      return ShaderMask(
                        blendMode: BlendMode.srcIn,
                        shaderCallback: (bounds) => ui.Gradient.linear(
                          Offset(bounds.left, 0),
                          Offset(bounds.right, 0),
                          [
                            AppColors.textPrimary,
                            Colors.white,
                            const Color(0xFFB0A0F8), // violet highlight
                            Colors.white,
                            AppColors.textPrimary,
                          ],
                          [
                            (pos - 0.25).clamp(0.0, 1.0),
                            (pos - 0.08).clamp(0.0, 1.0),
                            pos.clamp(0.0, 1.0),
                            (pos + 0.08).clamp(0.0, 1.0),
                            (pos + 0.25).clamp(0.0, 1.0),
                          ],
                        ),
                        child: child!,
                      );
                    },
                    child: Text(
                      DecayService.formatActivity(value),
                      style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                            fontFeatures: const [FontFeature.tabularFigures()],
                            fontWeight: FontWeight.w700,
                            fontSize: 36,
                            letterSpacing: -0.5,
                            color: AppColors.textPrimary,
                          ),
                    ),
                  ),
                ),
                Text(
                  widget.unit.label,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: AppColors.primaryText,
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),
          const Divider(height: 1, color: AppColors.border),
          const SizedBox(height: 14),

          // ── Stat chips (staggered entrance) ───────────────────────
          Row(
            children: [
              _StatChip(label: 'Restante', value: '$pct%', color: AppColors.success)
                  .animate().fadeIn(delay: 100.ms, duration: 350.ms)
                  .slideY(begin: 0.3, end: 0, curve: Curves.easeOutBack)
                  .scale(begin: const Offset(0.82, 0.82), end: const Offset(1, 1), delay: 100.ms, duration: 350.ms, curve: Curves.easeOutBack),
              const SizedBox(width: 8),
              _StatChip(label: 'Vidas medias', value: halfLives, color: AppColors.accent)
                  .animate().fadeIn(delay: 200.ms, duration: 350.ms)
                  .slideY(begin: 0.3, end: 0, curve: Curves.easeOutBack)
                  .scale(begin: const Offset(0.82, 0.82), end: const Offset(1, 1), delay: 200.ms, duration: 350.ms, curve: Curves.easeOutBack),
              const SizedBox(width: 8),
              _StatChip(
                      label: 'Reducción',
                      value: '${(100 - double.parse(pct)).toStringAsFixed(2)}%',
                      color: AppColors.error)
                  .animate().fadeIn(delay: 300.ms, duration: 350.ms)
                  .slideY(begin: 0.3, end: 0, curve: Curves.easeOutBack)
                  .scale(begin: const Offset(0.82, 0.82), end: const Offset(1, 1), delay: 300.ms, duration: 350.ms, curve: Curves.easeOutBack),
            ],
          ),
          const SizedBox(height: 12),
          _DecayBar(fraction: fraction),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatChip(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(value,
                style: TextStyle(
                    color: color == AppColors.error ? AppColors.errorText : color,
                    fontSize: 13,
                    fontWeight: FontWeight.w700)),
            Text(label,
                style: const TextStyle(
                    color: AppColors.textPrimary, fontSize: 10)),
          ],
        ),
      ),
    );
  }
}

class _DecayBar extends StatefulWidget {
  final double fraction;
  const _DecayBar({required this.fraction});

  @override
  State<_DecayBar> createState() => _DecayBarState();
}

class _DecayBarState extends State<_DecayBar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _anim = Tween(begin: 0.0, end: widget.fraction)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'ACTIVIDAD RESTANTE',
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: AppColors.textSecondary,
                letterSpacing: 1,
              ),
        ),
        const SizedBox(height: 6),
        AnimatedBuilder(
          animation: _anim,
          builder: (_, __) {
            return ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: _anim.value,
                backgroundColor: AppColors.cardHover,
                valueColor: AlwaysStoppedAnimation(
                  Color.lerp(AppColors.error, AppColors.success, _anim.value)!,
                ),
                minHeight: 8,
              ),
            );
          },
        ),
      ],
    );
  }
}

class _CalculateFooter extends StatelessWidget {
  final bool canCalculate;
  final bool isCalculating;
  final bool hasResult;
  final VoidCallback onTap;

  const _CalculateFooter({
    required this.canCalculate,
    required this.isCalculating,
    required this.hasResult,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    if (hasResult) return const SizedBox.shrink();

    const label = 'Calcular actividad residual';
    const icon = Icon(Icons.calculate_outlined, color: Colors.white, size: 18);

    return AnimatedSlide(
      offset: canCalculate ? Offset.zero : const Offset(0, 0.15),
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
      child: AnimatedOpacity(
        opacity: canCalculate ? 1.0 : 0.4,
        duration: const Duration(milliseconds: 300),
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          decoration: const BoxDecoration(
            color: AppColors.surface,
            border: Border(
                top: BorderSide(color: AppColors.border, width: 1)),
          ),
          child: GradientBorderButton(
            label: label,
            isLoading: isCalculating,
            onTap: canCalculate ? onTap : null,
            icon: icon,
          ),
        ),
      ),
    );
  }
}

class _IsotopePickerSheet extends StatelessWidget {
  final Isotope selected;
  final ScrollController scrollController;
  final ValueChanged<Isotope> onSelect;

  const _IsotopePickerSheet({
    required this.selected,
    required this.scrollController,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final grouped = <String, List<Isotope>>{};
    for (final iso in kIsotopes) {
      grouped.putIfAbsent(iso.category, () => []).add(iso);
    }

    return ListView(
      controller: scrollController,
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
      children: [
        Center(
            child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                    color: AppColors.border,
                    borderRadius: BorderRadius.circular(2)))),
        const SizedBox(height: 16),
        Text('Seleccionar isótopo',
            style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 16),
        ...grouped.entries.map((entry) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 8, top: 4),
                  child: Text(
                    entry.key.toUpperCase(),
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: AppColors.textSecondary,
                          letterSpacing: 1.2,
                        ),
                  ),
                ),
                ...entry.value.map((iso) {
                  final isSelected = iso.id == selected.id;
                  return ListTile(
                    dense: true,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    tileColor: isSelected
                        ? AppColors.primaryGlow
                        : Colors.transparent,
                    leading: _IsotopePill(isotope: iso),
                    title: Text(iso.name,
                        style: TextStyle(
                            color: isSelected
                                ? AppColors.primaryText
                                : AppColors.textPrimary,
                            fontWeight: isSelected
                                ? FontWeight.w700
                                : FontWeight.w500)),
                    subtitle: Text(iso.halfLifeDisplay,
                        style: Theme.of(context).textTheme.bodySmall),
                    trailing: isSelected
                        ? const Icon(Icons.check_circle_rounded,
                            color: AppColors.primaryText, size: 18)
                        : null,
                    onTap: () => onSelect(iso),
                  );
                }),
                const SizedBox(height: 8),
              ],
            )),
      ],
    );
  }
}

class _QuickTimeOption {
  final String label;
  final double hours;
  final bool isHalfLife;

  _QuickTimeOption(
      {required this.label, required this.hours, this.isHalfLife = false});
}

// ── Custom Date/Time Picker ───────────────────────────────────────────────────

class _DateTimePickerSheet extends StatefulWidget {
  final DateTime initial;
  const _DateTimePickerSheet({required this.initial});

  @override
  State<_DateTimePickerSheet> createState() => _DateTimePickerSheetState();
}

class _DateTimePickerSheetState extends State<_DateTimePickerSheet>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  late DateTime _selectedDate;
  late int _hour;
  late int _minute;
  late FixedExtentScrollController _hourCtrl;
  late FixedExtentScrollController _minCtrl;

  static const _months = [
    'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
    'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
  ];
  static const _dayHeaders = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];
  static const _shortMonths = [
    'ene', 'feb', 'mar', 'abr', 'may', 'jun',
    'jul', 'ago', 'sep', 'oct', 'nov', 'dic'
  ];
  static const _shortDays = ['lun', 'mar', 'mié', 'jue', 'vie', 'sáb', 'dom'];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _selectedDate = widget.initial;
    _hour = widget.initial.hour;
    _minute = widget.initial.minute;
    _hourCtrl = FixedExtentScrollController(initialItem: _hour);
    _minCtrl = FixedExtentScrollController(initialItem: _minute);
    _tab.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _tab.dispose();
    _hourCtrl.dispose();
    _minCtrl.dispose();
    super.dispose();
  }

  DateTime get _result {
    final h = _hourCtrl.hasClients ? _hourCtrl.selectedItem : _hour;
    final m = _minCtrl.hasClients ? _minCtrl.selectedItem : _minute;
    return DateTime(_selectedDate.year, _selectedDate.month, _selectedDate.day, h, m);
  }

  String get _confirmLabel {
    final d = _selectedDate;
    final dow = _shortDays[(d.weekday - 1) % 7];
    final mon = _shortMonths[d.month - 1];
    if (_tab.index == 0) {
      return 'Confirmar — $dow ${d.day} $mon';
    } else {
      final h = _hourCtrl.hasClients ? _hourCtrl.selectedItem : _hour;
      final m = _minCtrl.hasClients ? _minCtrl.selectedItem : _minute;
      return 'Confirmar — ${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}';
    }
  }

  void _prevMonth() {
    setState(() {
      _selectedDate = DateTime(_selectedDate.year, _selectedDate.month - 1, 1);
    });
  }

  void _nextMonth() {
    setState(() {
      _selectedDate = DateTime(_selectedDate.year, _selectedDate.month + 1, 1);
    });
  }

  void _selectDay(int day) {
    HapticFeedback.selectionClick();
    setState(() {
      _selectedDate = DateTime(_selectedDate.year, _selectedDate.month, day);
    });
  }

  void _goNow() {
    final now = DateTime.now();
    setState(() {
      _hour = now.hour;
      _minute = now.minute;
    });
    _hourCtrl.animateToItem(_hour,
        duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    _minCtrl.animateToItem(_minute,
        duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    HapticFeedback.lightImpact();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 36, height: 4,
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Tabs
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: TabBar(
                controller: _tab,
                indicator: BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.circular(9),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                labelColor: Colors.white,
                unselectedLabelColor: AppColors.textSecondary,
                labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                dividerColor: Colors.transparent,
                tabs: const [
                  Tab(text: 'Fecha'),
                  Tab(text: 'Hora'),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Tab content
            SizedBox(
              height: 320,
              child: TabBarView(
                controller: _tab,
                children: [
                  _buildCalendar(),
                  _buildTimePicker(),
                ],
              ),
            ),

            // Confirm button
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
              child: Column(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context, _result),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [AppColors.primary, AppColors.primaryLight],
                        ),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        _confirmLabel,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      alignment: Alignment.center,
                      child: const Text(
                        'Cancelar',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w500,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCalendar() {
    final today = DateTime.now();
    final firstDay = DateTime(_selectedDate.year, _selectedDate.month, 1);
    // Monday-based week offset
    int startOffset = (firstDay.weekday - 1) % 7;
    final daysInMonth =
        DateTime(_selectedDate.year, _selectedDate.month + 1, 0).day;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          // Month navigation
          Row(
            children: [
              GestureDetector(
                onTap: _prevMonth,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.card,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: const Icon(Icons.chevron_left_rounded,
                      color: AppColors.textPrimary, size: 20),
                ),
              ),
              Expanded(
                child: Text(
                  '${_months[_selectedDate.month - 1]} ${_selectedDate.year}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                  ),
                ),
              ),
              GestureDetector(
                onTap: _nextMonth,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.card,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: const Icon(Icons.chevron_right_rounded,
                      color: AppColors.textPrimary, size: 20),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Day headers
          Row(
            children: _dayHeaders.map((d) => Expanded(
              child: Text(d,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            )).toList(),
          ),
          const SizedBox(height: 6),

          // Grid
          Expanded(
            child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 7,
                childAspectRatio: 1,
              ),
              itemCount: startOffset + daysInMonth,
              itemBuilder: (_, i) {
                if (i < startOffset) return const SizedBox();
                final day = i - startOffset + 1;
                final isSelected = day == _selectedDate.day;
                final isToday = day == today.day &&
                    _selectedDate.month == today.month &&
                    _selectedDate.year == today.year;

                return GestureDetector(
                  onTap: () => _selectDay(day),
                  child: Container(
                    margin: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.primary
                          : Colors.transparent,
                      shape: BoxShape.circle,
                      border: isToday && !isSelected
                          ? Border.all(color: AppColors.primary, width: 1.5)
                          : null,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      '$day',
                      style: TextStyle(
                        color: isSelected
                            ? Colors.white
                            : isToday
                                ? AppColors.primaryText
                                : AppColors.textPrimary,
                        fontSize: 13,
                        fontWeight: isSelected || isToday
                            ? FontWeight.w700
                            : FontWeight.w400,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimePicker() {
    return Column(
      children: [
        // "Ahora" button
        Align(
          alignment: Alignment.centerRight,
          child: GestureDetector(
            onTap: _goNow,
            child: Container(
              margin: const EdgeInsets.only(right: 20),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(
                color: AppColors.primaryGlow,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.primary.withOpacity(0.4)),
              ),
              child: const Text(
                'Ahora',
                style: TextStyle(
                  color: AppColors.primaryLight,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),

        // Drum roll
        Expanded(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Hours
              SizedBox(
                width: 80,
                child: ListWheelScrollView.useDelegate(
                  controller: _hourCtrl,
                  itemExtent: 52,
                  perspective: 0.003,
                  diameterRatio: 1.8,
                  physics: const FixedExtentScrollPhysics(),
                  onSelectedItemChanged: (v) => setState(() => _hour = v),
                  childDelegate: ListWheelChildBuilderDelegate(
                    childCount: 24,
                    builder: (_, i) => _WheelItem(
                      label: i.toString().padLeft(2, '0'),
                      isSelected: i == _hour,
                    ),
                  ),
                ),
              ),

              // Separator
              const Padding(
                padding: EdgeInsets.only(bottom: 4),
                child: Text(
                  ':',
                  style: TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 32,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),

              // Minutes
              SizedBox(
                width: 80,
                child: ListWheelScrollView.useDelegate(
                  controller: _minCtrl,
                  itemExtent: 52,
                  perspective: 0.003,
                  diameterRatio: 1.8,
                  physics: const FixedExtentScrollPhysics(),
                  onSelectedItemChanged: (v) => setState(() => _minute = v),
                  childDelegate: ListWheelChildBuilderDelegate(
                    childCount: 60,
                    builder: (_, i) => _WheelItem(
                      label: i.toString().padLeft(2, '0'),
                      isSelected: i == _minute,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

      ],
    );
  }
}

class _WheelItem extends StatelessWidget {
  final String label;
  final bool isSelected;
  const _WheelItem({required this.label, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      decoration: isSelected
          ? BoxDecoration(
              color: AppColors.primaryGlow,
              borderRadius: BorderRadius.circular(10),
            )
          : null,
      child: Text(
        label,
        style: TextStyle(
          color: isSelected ? AppColors.primaryLight : AppColors.textSecondary,
          fontSize: isSelected ? 28 : 22,
          fontWeight: isSelected ? FontWeight.w700 : FontWeight.w400,
        ),
      ),
    );
  }
}

// ── Result Reveal Sheet ───────────────────────────────────────────────────────

class _ResultRevealSheet extends StatefulWidget {
  final double result;
  final double initialActivity;
  final RadioUnit unit;
  final Isotope isotope;
  final double elapsedHours;

  const _ResultRevealSheet({
    required this.result,
    required this.initialActivity,
    required this.unit,
    required this.isotope,
    required this.elapsedHours,
  });

  @override
  State<_ResultRevealSheet> createState() => _ResultRevealSheetState();
}

class _ResultRevealSheetState extends State<_ResultRevealSheet>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ringCtrl;
  late final Animation<double> _ringAnim;
  bool _copied = false;

  @override
  void initState() {
    super.initState();
    _ringCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _ringAnim = CurvedAnimation(parent: _ringCtrl, curve: Curves.easeOutCubic);
    _ringCtrl.forward();
  }

  @override
  void dispose() {
    _ringCtrl.dispose();
    super.dispose();
  }

  void _copy() async {
    HapticFeedback.lightImpact();
    final text = '${DecayService.formatActivity(widget.result)} ${widget.unit.label}';
    await Clipboard.setData(ClipboardData(text: text));
    setState(() => _copied = true);
    await Future.delayed(const Duration(milliseconds: 1800));
    if (mounted) setState(() => _copied = false);
  }

  @override
  Widget build(BuildContext context) {
    final fraction = widget.result / widget.initialActivity;
    final pct = (fraction * 100).toStringAsFixed(1);
    final halfLives = (widget.elapsedHours / widget.isotope.halfLifeHours).toStringAsFixed(2);
    final reduction = (100 - fraction * 100).toStringAsFixed(1);

    // Semantic color: green >60%, amber 20-60%, red <20%
    final Color semanticColor;
    if (fraction > 0.60) {
      semanticColor = AppColors.success;
    } else if (fraction > 0.20) {
      semanticColor = AppColors.warning;
    } else {
      semanticColor = AppColors.error;
    }

    return Theme(
      data: AppTheme.dark,
      child: DraggableScrollableSheet(
      initialChildSize: 0.90,
      minChildSize: 0.55,
      maxChildSize: 0.95,
      snap: true,
      builder: (_, scrollCtrl) => Container(
        decoration: const BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          border: Border(
            top: BorderSide(color: AppColors.border, width: 0.5),
          ),
        ),
            child: ListView(
              controller: scrollCtrl,
              padding: EdgeInsets.only(
                left: 24,
                right: 24,
                bottom: MediaQuery.of(context).padding.bottom + 24,
              ),
              children: [
                // ── Handle ───────────────────────────────────────────
                Center(
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 12),
                    width: 36,
                    height: 4,
                    decoration: BoxDecoration(
                      color: AppColors.border,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 8),

                // ── Isotope pill + label ─────────────────────────────
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _IsotopePill(isotope: widget.isotope),
                    Text(
                      'Actividad residual',
                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                        color: AppColors.textSecondary,
                        letterSpacing: 0.4,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 32),

                // ── Activity Ring + Number ────────────────────────────
                Center(
                  child: AnimatedBuilder(
                    animation: _ringAnim,
                    builder: (_, __) => _ActivityRing(
                      fraction: fraction * _ringAnim.value,
                      semanticColor: semanticColor,
                      size: 220,
                      strokeWidth: 12,
                      child: Padding(
                        padding: const EdgeInsets.all(28),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TweenAnimationBuilder<double>(
                              tween: Tween(begin: 0, end: widget.result),
                              duration: const Duration(milliseconds: 950),
                              curve: Curves.easeOutCubic,
                              builder: (_, val, __) => FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  DecayService.formatActivity(val),
                                  style: const TextStyle(
                                    fontFamily: 'Inter',
                                    fontSize: 40,
                                    fontWeight: FontWeight.w800,
                                    color: AppColors.textPrimary,
                                    letterSpacing: -1.5,
                                    fontFeatures: [FontFeature.tabularFigures()],
                                  ),
                                ),
                              ),
                            ),
                            Text(
                              widget.unit.label,
                              style: TextStyle(
                                fontFamily: 'Inter',
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: semanticColor == AppColors.error
                                    ? AppColors.errorText
                                    : semanticColor,
                                letterSpacing: 0.2,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                // ── Pct remaining label ───────────────────────────────
                Center(
                  child: AnimatedBuilder(
                    animation: _ringAnim,
                    builder: (_, __) => Text(
                      '$pct% del total inicial',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: semanticColor == AppColors.error
                            ? AppColors.errorText
                            : semanticColor,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 28),

                // ── Bento stat grid ───────────────────────────────────
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 3,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.3,
                  children: [
                    _BentoStat(
                      label: 'Restante',
                      value: '$pct%',
                      icon: Icons.water_drop_outlined,
                      color: semanticColor,
                    ),
                    _BentoStat(
                      label: 'Vidas medias',
                      value: halfLives,
                      icon: Icons.timelapse_rounded,
                      color: AppColors.accent,
                    ),
                    _BentoStat(
                      label: 'Reducción',
                      value: '$reduction%',
                      icon: Icons.trending_down_rounded,
                      color: AppColors.error,
                    ),
                  ],
                ),
                const SizedBox(height: 28),

                // ── Copy button ───────────────────────────────────────
                GestureDetector(
                  onTap: _copy,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color: _copied
                          ? AppColors.success.withOpacity(0.12)
                          : AppColors.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: _copied
                            ? AppColors.success.withOpacity(0.4)
                            : AppColors.border,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 200),
                          child: _copied
                              ? const Icon(Icons.check_rounded,
                                  key: ValueKey('chk'),
                                  size: 18,
                                  color: AppColors.success)
                              : const Icon(Icons.copy_rounded,
                                  key: ValueKey('cpy'),
                                  size: 18,
                                  color: AppColors.textSecondary),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          _copied ? 'Copiado' : 'Copiar resultado',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: _copied ? AppColors.success : AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                // ── New calculation ───────────────────────────────────
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [AppColors.primary, AppColors.primaryDark],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primary.withOpacity(0.35),
                          blurRadius: 20,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add_rounded, size: 18, color: Colors.white),
                        SizedBox(width: 8),
                        Text(
                          'Nuevo cálculo',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
      ),
    );
  }
}

// ── Activity Ring ─────────────────────────────────────────────────────────────

class _ActivityRing extends StatelessWidget {
  final double fraction;
  final Color semanticColor;
  final double size;
  final double strokeWidth;
  final Widget child;

  const _ActivityRing({
    required this.fraction,
    required this.semanticColor,
    required this.size,
    required this.strokeWidth,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomPaint(
            size: Size(size, size),
            painter: _RingPainter(
              fraction: fraction,
              semanticColor: semanticColor,
              strokeWidth: strokeWidth,
            ),
          ),
          child,
        ],
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final double fraction;
  final Color semanticColor;
  final double strokeWidth;

  _RingPainter({
    required this.fraction,
    required this.semanticColor,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - strokeWidth) / 2;
    const startAngle = -math.pi / 2; // top

    // Track
    final trackPaint = Paint()
      ..color = AppColors.cardHover
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      0,
      math.pi * 2,
      false,
      trackPaint,
    );

    if (fraction <= 0) return;

    // Glow layer (wider, blurred)
    final glowPaint = Paint()
      ..color = semanticColor.withOpacity(0.30)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth + 10
      ..strokeCap = StrokeCap.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      math.pi * 2 * fraction.clamp(0, 1),
      false,
      glowPaint,
    );

    // Foreground arc
    final paint = Paint()
      ..color = semanticColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      math.pi * 2 * fraction.clamp(0, 1),
      false,
      paint,
    );
  }

  @override
  bool shouldRepaint(_RingPainter old) =>
      old.fraction != fraction || old.semanticColor != semanticColor;
}

// ── Bento Stat Chip ───────────────────────────────────────────────────────────

class _BentoStat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _BentoStat({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.07),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.18)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Icon(icon, size: 16, color: color),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: color == AppColors.error
                      ? AppColors.errorText
                      : color == AppColors.accent
                          ? AppColors.accentText
                          : color,
                  letterSpacing: -0.3,
                ),
              ),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                  color: AppColors.textPrimary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
