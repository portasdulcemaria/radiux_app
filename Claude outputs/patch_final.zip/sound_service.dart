import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';

/// Servicio singleton para feedback de audio clínico.
/// Cada sonido está diseñado para la acción que representa.
class SoundService {
  SoundService._();
  static final SoundService instance = SoundService._();

  bool _enabled = true;
  bool get enabled => _enabled;
  set enabled(bool v) => _enabled = v;

  Future<void> init() async {
    try {
      await AudioPlayer.global.setAudioContext(
        AudioContext(
          iOS: AudioContextIOS(
            category: AVAudioSessionCategory.ambient,
            options: {AVAudioSessionOptions.mixWithOthers},
          ),
          android: AudioContextAndroid(
            isSpeakerphoneOn: false,
            stayAwake: false,
            contentType: AndroidContentType.sonification,
            usageType: AndroidUsageType.assistanceSonification,
            audioFocus: AndroidAudioFocus.none,
          ),
        ),
      );
    } catch (e) {
      debugPrint('[SoundService] init error: $e');
    }
  }

  /// Tap genérico UI — botones secundarios, toggles.
  Future<void> tick() => _play('tick');

  /// Selección de ítem en lista — unidades, isótopos.
  Future<void> select() => _play('select');

  /// Intercambio de valores — botón swap (↔).
  Future<void> swap() => _play('swap');

  /// Copiar resultado al portapapeles.
  Future<void> copy() => _play('copy');

  /// Cálculo exitoso — resultado disponible.
  Future<void> success() => _play('success');

  /// Error de validación — entrada inválida.
  Future<void> error() => _play('error');

  Future<void> _play(String name) async {
    if (!_enabled) return;
    try {
      final player = AudioPlayer();
      await player.setVolume(0.7);
      await player.play(AssetSource('sounds/$name.wav'));
      player.onPlayerComplete.listen((_) => player.dispose());
    } catch (e) {
      debugPrint('[SoundService] play($name) error: $e');
    }
  }
}
