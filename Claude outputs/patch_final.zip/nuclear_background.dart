import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

// ── Animated nuclear background ───────────────────────────────────────────────
// Tres capas:
//   1. Halo de luz central — gradiente radial suave con parallax lento
//   2. Gradient mesh — 3 blobs de color que se mueven sinusoidalmente
//   3. Partículas — puntos muy pequeños que flotan hacia arriba
//
// Diseñado para ser sutil: solo se percibe en fondos oscuros, sin competir
// con el contenido clínico.

class AnimatedNuclearBackground extends StatefulWidget {
  final Widget child;
  const AnimatedNuclearBackground({super.key, required this.child});

  @override
  State<AnimatedNuclearBackground> createState() =>
      _AnimatedNuclearBackgroundState();
}

class _AnimatedNuclearBackgroundState extends State<AnimatedNuclearBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 24),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // ── Capa 1: halo de luz central con parallax ──────────────────────
        Positioned.fill(
          child: AnimatedBuilder(
            animation: _ctrl,
            builder: (_, __) => CustomPaint(
              painter: _HaloPainter(_ctrl.value),
            ),
          ),
        ),

        // ── Capa 2: gradient mesh ──────────────────────────────────────────
        Positioned.fill(
          child: AnimatedBuilder(
            animation: _ctrl,
            builder: (_, __) => CustomPaint(
              painter: _GradientMeshPainter(_ctrl.value),
            ),
          ),
        ),

        // ── Capa 3: partículas de decaimiento ──────────────────────────────
        Positioned.fill(
          child: _ParticleField(controller: _ctrl),
        ),

        // ── Contenido de la app ────────────────────────────────────────────
        widget.child,
      ],
    );
  }
}

// ── Halo de luz central (parallax) ───────────────────────────────────────────
// Un resplandor suave centrado que se desplaza muy lentamente.
// Simula una fuente de luz interna que "respira".

class _HaloPainter extends CustomPainter {
  final double t;
  _HaloPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final W = size.width;
    final H = size.height;

    // Movimiento muy lento tipo parallax — se desplaza ±8% del ancho
    final cx = W * (0.50 + 0.08 * math.sin(t * math.pi * 2 * 0.4));
    final cy = H * (0.42 + 0.06 * math.cos(t * math.pi * 2 * 0.3));
    final radius = W * 0.70;

    // Pulso suave de opacidad (0.06 → 0.13) sincronizado con el movimiento
    final pulse = 0.06 + 0.07 * math.sin(t * math.pi * 2 * 0.5 + 0.8);

    final paint = Paint()
      ..shader = RadialGradient(
        colors: [
          AppColors.primary.withOpacity(pulse),
          AppColors.primary.withOpacity(0),
        ],
        stops: const [0.0, 1.0],
      ).createShader(Rect.fromCircle(center: Offset(cx, cy), radius: radius))
      ..blendMode = BlendMode.srcOver;

    canvas.drawCircle(Offset(cx, cy), radius, paint);
  }

  @override
  bool shouldRepaint(_HaloPainter old) => old.t != t;
}

// ── Gradient mesh painter ─────────────────────────────────────────────────────
// 3 blobs suaves — opacidad muy baja para no competir con el contenido.

class _GradientMeshPainter extends CustomPainter {
  final double t;
  _GradientMeshPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final W = size.width;
    final H = size.height;

    _drawBlob(
      canvas,
      center: Offset(
        W * (0.15 + 0.10 * math.sin(t * math.pi * 2 * 0.7)),
        H * (0.18 + 0.08 * math.cos(t * math.pi * 2 * 0.5)),
      ),
      radius: W * 0.45,
      color: AppColors.primary.withOpacity(0.07),
    );

    _drawBlob(
      canvas,
      center: Offset(
        W * (0.82 + 0.07 * math.cos(t * math.pi * 2 * 1.1)),
        H * (0.50 + 0.12 * math.sin(t * math.pi * 2 * 0.8)),
      ),
      radius: W * 0.40,
      color: const Color(0xFF7C3AED).withOpacity(0.06),
    );

    _drawBlob(
      canvas,
      center: Offset(
        W * (0.42 + 0.09 * math.sin(t * math.pi * 2 * 0.6 + 1.0)),
        H * (0.82 + 0.06 * math.cos(t * math.pi * 2 * 0.7)),
      ),
      radius: W * 0.38,
      color: AppColors.primaryDark.withOpacity(0.05),
    );
  }

  void _drawBlob(Canvas canvas,
      {required Offset center, required double radius, required Color color}) {
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [color, color.withOpacity(0)],
        stops: const [0.0, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..blendMode = BlendMode.srcOver;
    canvas.drawCircle(center, radius, paint);
  }

  @override
  bool shouldRepaint(_GradientMeshPainter old) => old.t != t;
}

// ── Particle field ────────────────────────────────────────────────────────────
// Partículas pequeñas y muy sutiles — máximo 20 simultáneas.

class _ParticleField extends StatefulWidget {
  final AnimationController controller;
  const _ParticleField({required this.controller});

  @override
  State<_ParticleField> createState() => _ParticleFieldState();
}

class _ParticleFieldState extends State<_ParticleField> {
  final _rng = math.Random();
  final List<_Particle> _particles = [];
  static const _maxParticles = 20;

  @override
  void initState() {
    super.initState();
    for (int i = 0; i < 10; i++) {
      _particles.add(_Particle.random(_rng, age: _rng.nextDouble()));
    }
    widget.controller.addListener(_tick);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    setState(() {
      for (final p in _particles) {
        p.update(0.016);
      }
      _particles.removeWhere((p) => p.isDead);
      while (_particles.length < _maxParticles) {
        _particles.add(_Particle.random(_rng));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _ParticlePainter(_particles));
  }
}

class _Particle {
  double x;
  double y;
  double vx;
  double vy;
  double size;
  double age;
  double lifeSpeed;
  final Color color;

  _Particle({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    required this.size,
    required this.age,
    required this.lifeSpeed,
    required this.color,
  });

  factory _Particle.random(math.Random rng, {double? age}) {
    final colors = [
      AppColors.primary,
      const Color(0xFF7C3AED),
      AppColors.primaryLight,
      AppColors.accent,
    ];
    return _Particle(
      x: rng.nextDouble(),
      y: rng.nextDouble(),
      vx: (rng.nextDouble() - 0.5) * 0.0004,
      vy: -(0.0002 + rng.nextDouble() * 0.0003),
      size: 0.8 + rng.nextDouble() * 1.4, // pequeñas: 0.8–2.2 px
      age: age ?? 0.0,
      lifeSpeed: 0.002 + rng.nextDouble() * 0.003,
      color: colors[rng.nextInt(colors.length)],
    );
  }

  void update(double dt) {
    x += vx;
    y += vy;
    age += lifeSpeed;
    if (x < 0) x += 1;
    if (x > 1) x -= 1;
  }

  bool get isDead => age >= 1.0 || y < -0.02;

  // Opacidad: fade-in rápido, plateau, fade-out
  double get opacity {
    if (age < 0.12) return age / 0.12;
    if (age > 0.78) return (1 - age) / 0.22;
    return 1.0;
  }
}

class _ParticlePainter extends CustomPainter {
  final List<_Particle> particles;
  _ParticlePainter(this.particles);

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in particles) {
      // Opacidad máxima ~28% para que sean sutiles pero visibles
      final paint = Paint()
        ..color = p.color.withOpacity(p.opacity * 0.28);
      canvas.drawCircle(
        Offset(p.x * size.width, p.y * size.height),
        p.size,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => true;
}
