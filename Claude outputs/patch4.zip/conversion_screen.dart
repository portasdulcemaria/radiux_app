import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../models/unit.dart';
import '../../models/decay_service.dart';
import '../../theme/app_theme.dart';
import '../../services/sound_service.dart';

// ─── Local palette (dark theme) ──────────────────────────────────────────────
const _kWhite       = AppColors.card;
const _kBorder      = AppColors.border;
const _kBg          = AppColors.cardHover;
const _kViolet      = AppColors.primary;
const _kTextPrimary = AppColors.textPrimary;
const _kTextSecond  = AppColors.textSecondary;
const _kTextTert    = AppColors.textDisabled;

class ConversionScreen extends StatefulWidget {
  const ConversionScreen({super.key});

  @override
  State<ConversionScreen> createState() => _ConversionScreenState();
}

class _ConversionScreenState extends State<ConversionScreen>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  final _inputController = TextEditingController();
  final _focusNode       = FocusNode();
  Timer? _debounce;

  RadioUnit _fromUnit = kUnits.first;
  RadioUnit _toUnit   = kUnits[4];

  double? _result;
  String? _errorText;

  bool get _hasInput => _inputController.text.isNotEmpty;

  @override
  void initState() {
    super.initState();
    _inputController.addListener(_onInputChanged);
    _focusNode.addListener(() => setState(() {}));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _inputController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onInputChanged() {
    setState(() {
      _errorText = null;
      if (_inputController.text.isEmpty) _result = null;
    });
    _debounce?.cancel();
    if (_inputController.text.isNotEmpty) {
      _debounce = Timer(const Duration(milliseconds: 350), _convertLive);
    }
  }

  void _convertLive() {
    final text  = _inputController.text.replaceAll(',', '.');
    final value = double.tryParse(text);
    if (value == null || value <= 0) return;
    final result = DecayService.convert(value, _fromUnit, _toUnit);
    setState(() => _result = result);
    HapticFeedback.lightImpact();
    SoundService.instance.success();
    _showResultSheet();
  }

  void _showResultSheet() {
    if (_result == null) return;
    _focusNode.unfocus();
    final resultValue = DecayService.formatActivity(_result!);
    final fromLabel   = _fromUnit.label;
    final toLabel     = _toUnit.label;
    final inputText   = _inputController.text;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      enableDrag: true,
      isDismissible: true,
      builder: (_) => _ResultSheet(
        input: inputText,
        fromLabel: fromLabel,
        toLabel: toLabel,
        result: resultValue,
        onCopy: () {
          Clipboard.setData(ClipboardData(text: '$resultValue $toLabel'));
          HapticFeedback.lightImpact();
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                const Icon(Icons.check_circle_rounded,
                    color: AppColors.success, size: 18),
                const SizedBox(width: 8),
                Text('$resultValue $toLabel copiado',
                    style: const TextStyle(color: _kTextPrimary)),
              ]),
              duration: const Duration(seconds: 2),
            ),
          );
        },
        onNewConversion: () => Navigator.pop(context),
      ),
    );
  }

  void _clear() {
    HapticFeedback.selectionClick();
    _debounce?.cancel();
    _inputController.clear();
    setState(() { _result = null; _errorText = null; });
    _focusNode.requestFocus();
  }

  void _swapUnits() {
    SoundService.instance.tick();
    setState(() {
      final tmp = _fromUnit;
      _fromUnit = _toUnit;
      _toUnit   = tmp;
      _result   = null;
    });
    if (_hasInput) _convertLive();
  }

  void _onUnitChanged(RadioUnit unit, bool isFrom) {
    setState(() {
      if (isFrom) _fromUnit = unit;
      else        _toUnit   = unit;
      _result = null;
    });
    if (_hasInput) _convertLive();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _focusNode.unfocus(),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Convertir',
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                color: _kTextTert,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.5,
              ),
            ).animate().fadeIn(duration: 300.ms),

            const SizedBox(height: 12),

            _ActivityInput(
              controller: _inputController,
              focusNode:  _focusNode,
              hasError:   _errorText != null,
              hasInput:   _hasInput,
              onClear:    _clear,
              fromUnit:   _fromUnit,
            ).animate().fadeIn(delay: 60.ms),

            if (_errorText != null)
              _ErrorRow(text: _errorText!)
                  .animate().fadeIn(duration: 200.ms).shakeX(amount: 4, hz: 4),

            const SizedBox(height: 20),

            _UnitRow(
              fromUnit:  _fromUnit,
              toUnit:    _toUnit,
              onFromTap: () => _showUnitPicker(isFrom: true),
              onToTap:   () => _showUnitPicker(isFrom: false),
              onSwap:    _swapUnits,
            ).animate().fadeIn(delay: 100.ms),
          ],
        ),
      ),
    );
  }

  void _showUnitPicker({required bool isFrom}) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _kWhite,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.55,
        minChildSize: 0.4,
        maxChildSize: 0.85,
        expand: false,
        builder: (_, scrollController) => _UnitPickerSheet(
          selected:         isFrom ? _fromUnit : _toUnit,
          excluded:         isFrom ? _toUnit   : _fromUnit,
          scrollController: scrollController,
          onSelect: (unit) {
            HapticFeedback.selectionClick();
            _onUnitChanged(unit, isFrom);
            Navigator.pop(context);
          },
        ),
      ),
    );
  }
}

// ── Activity Input with pulsing border ───────────────────────────────────────

class _ActivityInput extends StatefulWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final bool hasError;
  final bool hasInput;
  final VoidCallback onClear;
  final RadioUnit fromUnit;

  const _ActivityInput({
    required this.controller,
    required this.focusNode,
    required this.hasError,
    required this.hasInput,
    required this.onClear,
    required this.fromUnit,
  });

  @override
  State<_ActivityInput> createState() => _ActivityInputState();
}

class _ActivityInputState extends State<_ActivityInput>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseCtrl;
  late final Animation<double>   _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _pulseAnim = CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut);
    widget.focusNode.addListener(_onFocusChange);
    if (widget.focusNode.hasFocus) _pulseCtrl.repeat(reverse: true);
  }

  void _onFocusChange() {
    if (widget.focusNode.hasFocus) {
      _pulseCtrl.repeat(reverse: true);
    } else {
      _pulseCtrl.stop();
      _pulseCtrl.value = 0;
    }
    setState(() {});
  }

  @override
  void dispose() {
    widget.focusNode.removeListener(_onFocusChange);
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isFocused = widget.focusNode.hasFocus;

    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, child) {
        final borderOpacity = isFocused
            ? 0.40 + 0.35 * _pulseAnim.value  // pulsa entre 0.40 y 0.75
            : 0.0;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: widget.hasError
                  ? AppColors.error.withOpacity(0.7)
                  : isFocused
                      ? _kViolet.withOpacity(borderOpacity)
                      : _kBorder,
              width: widget.hasError || isFocused ? 1.5 : 1,
            ),
            color: _kWhite,
            boxShadow: [
              BoxShadow(
                color: isFocused
                    ? _kViolet.withOpacity(0.06 + 0.06 * _pulseAnim.value)
                    : Colors.black.withOpacity(0.04),
                blurRadius: isFocused ? 18 : 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: child,
        );
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Center(
              child: Text(
                widget.fromUnit.fullName,
                style: TextStyle(
                  color: _kViolet.withOpacity(0.8),
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 0.2,
                ),
              ),
            ),
          ),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: widget.controller,
                  focusNode:  widget.focusNode,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'[\d.,]')),
                  ],
                  style: const TextStyle(
                    color: _kTextPrimary,
                    fontSize: 44,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -1.5,
                    height: 1.1,
                  ),
                  textAlign: TextAlign.center,
                  decoration: const InputDecoration(
                    hintText: '',
                    border:        InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    contentPadding: EdgeInsets.fromLTRB(16, 4, 16, 18),
                    filled: false,
                  ),
                ),
              ),
              if (widget.hasInput)
                GestureDetector(
                  onTap: widget.onClear,
                  child: SizedBox(
                    width: 44,
                    height: 44,
                    child: Center(
                      child: Container(
                        margin: const EdgeInsets.only(right: 14),
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          color: _kBg,
                          shape: BoxShape.circle,
                          border: Border.all(color: _kBorder),
                        ),
                        child: const Icon(Icons.close_rounded,
                            size: 14, color: _kTextSecond),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Unit row con flip 3D en swap ─────────────────────────────────────────────

class _UnitRow extends StatefulWidget {
  final RadioUnit fromUnit;
  final RadioUnit toUnit;
  final VoidCallback onFromTap;
  final VoidCallback onToTap;
  final VoidCallback onSwap;

  const _UnitRow({
    required this.fromUnit,
    required this.toUnit,
    required this.onFromTap,
    required this.onToTap,
    required this.onSwap,
  });

  @override
  State<_UnitRow> createState() => _UnitRowState();
}

class _UnitRowState extends State<_UnitRow>
    with SingleTickerProviderStateMixin {
  late final AnimationController _flipCtrl;
  late final Animation<double>   _flipAnim;

  @override
  void initState() {
    super.initState();
    _flipCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
    );
    _flipAnim = CurvedAnimation(parent: _flipCtrl, curve: Curves.easeInOutCubic);
  }

  @override
  void dispose() {
    _flipCtrl.dispose();
    super.dispose();
  }

  void _handleSwap() {
    HapticFeedback.selectionClick();
    _flipCtrl.forward(from: 0);
    // Swap de datos en el midpoint de la animación
    Future.delayed(const Duration(milliseconds: 160), () {
      if (mounted) widget.onSwap();
    });
    // Segundo haptic al aterrizar
    Future.delayed(const Duration(milliseconds: 320), () {
      if (mounted) HapticFeedback.lightImpact();
    });
  }

  Widget _chip({
    required String dirLabel,
    required RadioUnit unit,
    required Color accentColor,
    required VoidCallback onTap,
    required bool isLeft,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedBuilder(
          animation: _flipAnim,
          builder: (_, child) {
            // Left chip: 0→π, Right chip: 0→-π (dirección opuesta)
            final angle = isLeft
                ? _flipAnim.value * math.pi
                : -_flipAnim.value * math.pi;
            return Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..setEntry(3, 2, 0.001) // perspectiva
                ..rotateY(angle),
              child: child,
            );
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: _kWhite,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _kBorder),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 6,
                    offset: const Offset(0, 2))
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(dirLabel,
                    style: const TextStyle(
                        color: _kTextTert, fontSize: 11, letterSpacing: 0.3)),
                const SizedBox(height: 2),
                Row(children: [
                  Text(unit.label,
                      style: TextStyle(
                          color: accentColor,
                          fontSize: 15,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(width: 4),
                  const Icon(Icons.expand_more_rounded,
                      size: 14, color: _kTextTert),
                ]),
                Text(unit.fullName,
                    style: const TextStyle(color: _kTextSecond, fontSize: 11),
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _chip(
          dirLabel:    'Desde',
          unit:        widget.fromUnit,
          accentColor: _kViolet,
          onTap:       widget.onFromTap,
          isLeft:      true,
        ),

        // Swap button con rotation propia
        AnimatedBuilder(
          animation: _flipAnim,
          builder: (_, child) => Transform.rotate(
            angle: _flipAnim.value * math.pi * 2,
            child: child,
          ),
          child: GestureDetector(
            onTap: _handleSwap,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 8),
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _kWhite,
                border: Border.all(color: _kBorder),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.03),
                      blurRadius: 6,
                      offset: const Offset(0, 2))
                ],
              ),
              child: const Icon(Icons.swap_horiz_rounded,
                  size: 16, color: _kViolet),
            ),
          ),
        ),

        _chip(
          dirLabel:    'Hacia',
          unit:        widget.toUnit,
          accentColor: AppColors.accent,
          onTap:       widget.onToTap,
          isLeft:      false,
        ),
      ],
    );
  }
}

class _ErrorRow extends StatelessWidget {
  final String text;
  const _ErrorRow({required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Row(children: [
        const Icon(Icons.warning_amber_rounded, size: 14, color: AppColors.error),
        const SizedBox(width: 6),
        Text(text,
            style: Theme.of(context)
                .textTheme
                .labelSmall
                ?.copyWith(color: AppColors.error)),
      ]),
    );
  }
}

// ── Result Sheet con backdrop blur ───────────────────────────────────────────

class _ResultSheet extends StatelessWidget {
  final String input;
  final String fromLabel;
  final String toLabel;
  final String result;
  final VoidCallback onCopy;
  final VoidCallback onNewConversion;

  const _ResultSheet({
    required this.input,
    required this.fromLabel,
    required this.toLabel,
    required this.result,
    required this.onCopy,
    required this.onNewConversion,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 24, sigmaY: 24),
        child: Container(
          decoration: const BoxDecoration(
            color: AppColors.surface.withOpacity(0.96),
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Handle + close
              Row(children: [
                const Spacer(),
                Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: _kBorder,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Expanded(
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: GestureDetector(
                      onTap: onNewConversion,
                      child: SizedBox(
                        width: 44,
                        height: 44,
                        child: Center(
                          child: Container(
                            width: 30,
                            height: 30,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _kBg,
                              border: Border.all(color: _kBorder),
                            ),
                            child: const Icon(Icons.close_rounded,
                                size: 15, color: _kTextSecond),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ]),
              const SizedBox(height: 24),

              // Conversion badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _kViolet.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _kViolet.withOpacity(0.15)),
                ),
                child: Text(
                  '$fromLabel → $toLabel',
                  style: const TextStyle(
                    color: _kViolet,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
              const SizedBox(height: 10),

              Text(
                '$input $fromLabel',
                style: const TextStyle(color: _kTextSecond, fontSize: 15),
              ),

              const SizedBox(height: 24),

              // Result con scale-in
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text(
                    result,
                    style: const TextStyle(
                      color: _kTextPrimary,
                      fontSize: 48,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -1.5,
                      height: 1,
                    ),
                  ).animate().scale(
                    begin: const Offset(0.85, 0.85),
                    end: const Offset(1, 1),
                    duration: 350.ms,
                    curve: Curves.easeOutBack,
                  ).fadeIn(duration: 250.ms),
                  const SizedBox(width: 10),
                  Text(
                    toLabel,
                    style: const TextStyle(
                      color: _kViolet,
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                    ),
                  ).animate().fadeIn(delay: 100.ms, duration: 250.ms),
                ],
              ),

              const SizedBox(height: 32),

              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: onCopy,
                  icon: const Icon(Icons.copy_rounded, size: 18),
                  label: const Text('Copiar resultado'),
                  style: FilledButton.styleFrom(
                    backgroundColor: _kViolet,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ).animate().fadeIn(delay: 150.ms).slideY(begin: 0.2, end: 0, delay: 150.ms, duration: 300.ms, curve: Curves.easeOutBack),

              const SizedBox(height: 12),

              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: onNewConversion,
                  style: TextButton.styleFrom(
                    foregroundColor: _kTextSecond,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text('Modificar valor',
                      style: TextStyle(fontSize: 15)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Unit Picker Sheet ─────────────────────────────────────────────────────────

class _UnitPickerSheet extends StatelessWidget {
  final RadioUnit selected;
  final RadioUnit excluded;
  final ValueChanged<RadioUnit> onSelect;
  final ScrollController scrollController;

  const _UnitPickerSheet({
    required this.selected,
    required this.excluded,
    required this.onSelect,
    required this.scrollController,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      controller: scrollController,
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      children: [
        Center(
          child: Container(
            width: 36,
            height: 4,
            decoration: BoxDecoration(
              color: _kBorder,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text('Seleccioná unidad',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(color: _kTextPrimary)),
        const SizedBox(height: 12),
        ...kUnits.asMap().entries.map((e) {
          final unit       = e.value;
          final isSelected = unit.id == selected.id;
          final isExcluded = unit.id == excluded.id;
          return ListTile(
            dense: true,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            tileColor: isSelected ? _kViolet.withOpacity(0.06) : Colors.transparent,
            enabled: !isExcluded,
            leading: Container(
              width: 44,
              height: 36,
              decoration: BoxDecoration(
                color: isSelected ? _kViolet.withOpacity(0.08) : _kBg,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: isSelected ? _kViolet.withOpacity(0.35) : _kBorder,
                ),
              ),
              alignment: Alignment.center,
              child: Text(
                unit.label,
                style: TextStyle(
                  color:      isSelected ? _kViolet : _kTextSecond,
                  fontWeight: FontWeight.w700,
                  fontSize:   12,
                ),
              ),
            ),
            title: Text(
              unit.fullName,
              style: TextStyle(
                color: isExcluded ? _kTextTert : _kTextPrimary,
                fontSize: 14,
              ),
            ),
            trailing: isSelected
                ? const Icon(Icons.check_circle_rounded,
                    color: _kViolet, size: 18)
                : null,
            onTap: isExcluded ? null : () => onSelect(unit),
          ).animate().fadeIn(
            delay: Duration(milliseconds: 30 * e.key),
            duration: 200.ms,
          );
        }),
      ],
    );
  }
}
