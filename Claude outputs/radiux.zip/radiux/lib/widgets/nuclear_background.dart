import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

// ── Animated nuclear background ───────────────────────────────────────────────
// Dos capas:
//   1. Gradient mesh — 3 blobs de color que se mueven sinusoidalmente (muy lento)
//   2. Partículas — pequeños puntos que "decaen": nacen, flotan y desaparecen
//
// Toda la opacidad está calibrada para no competir con el contenido clínico.

class AnimatedNuclearBackground extends StatefulWidget {
  final Widget child;
  const AnimatedNuclearBackground({super.key, required this.child});

  @override
  State<AnimatedNuclearBackground> createState() =>
      _AnimatedNuclearBackgroundState();
}

class _AnimatedNuclearBackgroundState extends State<AnimatedNuclearBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat(); // loop continuo
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // ── Capa 1: gradient mesh ──────────────────────────────────────────
        Positioned.fill(
          child: AnimatedBuilder(
            animation: _ctrl,
            builder: (_, __) => CustomPaint(
              painter: _GradientMeshPainter(_ctrl.value),
            ),
          ),
        ),

        // ── Capa 2: partículas de decaimiento ──────────────────────────────
        Positioned.fill(
          child: _ParticleField(controller: _ctrl),
        ),

        // ── Contenido de la app ────────────────────────────────────────────
        widget.child,
      ],
    );
  }
}

// ── Gradient mesh painter ─────────────────────────────────────────────────────
// 3 blobs indigo/violeta con posiciones sinusoidales distintas.
// Opacidad máxima: 0.10 → prácticamente invisible a simple vista.

class _GradientMeshPainter extends CustomPainter {
  final double t; // 0.0 → 1.0

  _GradientMeshPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final W = size.width;
    final H = size.height;

    // Blob A — esquina superior izquierda, movimiento lento
    _drawBlob(
      canvas,
      center: Offset(
        W * (0.15 + 0.12 * math.sin(t * math.pi * 2)),
        H * (0.20 + 0.10 * math.cos(t * math.pi * 2 * 0.7)),
      ),
      radius: W * 0.55,
      color: AppColors.primary.withOpacity(0.22),
    );

    // Blob B — centro-derecha
    _drawBlob(
      canvas,
      center: Offset(
        W * (0.80 + 0.08 * math.cos(t * math.pi * 2 * 1.3)),
        H * (0.45 + 0.15 * math.sin(t * math.pi * 2 * 0.9)),
      ),
      radius: W * 0.50,
      color: const Color(0xFF7C3AED).withOpacity(0.18),
    );

    // Blob C — parte inferior, drift muy suave
    _drawBlob(
      canvas,
      center: Offset(
        W * (0.40 + 0.10 * math.sin(t * math.pi * 2 * 0.6 + 1.0)),
        H * (0.80 + 0.08 * math.cos(t * math.pi * 2 * 0.8)),
      ),
      radius: W * 0.45,
      color: AppColors.primaryDark.withOpacity(0.16),
    );
  }

  void _drawBlob(Canvas canvas,
      {required Offset center, required double radius, required Color color}) {
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [color, color.withOpacity(0)],
        stops: const [0.0, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..blendMode = BlendMode.plus;
    canvas.drawCircle(center, radius, paint);
  }

  @override
  bool shouldRepaint(_GradientMeshPainter old) => old.t != t;
}

// ── Particle field ────────────────────────────────────────────────────────────
// Hasta 28 partículas vivas simultáneamente.
// Cada una tiene: posición, tamaño, velocidad, ángulo de deriva y vida.

class _ParticleField extends StatefulWidget {
  final AnimationController controller;
  const _ParticleField({required this.controller});

  @override
  State<_ParticleField> createState() => _ParticleFieldState();
}

class _ParticleFieldState extends State<_ParticleField> {
  final _rng = math.Random();
  final List<_Particle> _particles = [];
  static const _maxParticles = 28;

  @override
  void initState() {
    super.initState();
    // Sembrar algunas partículas iniciales distribuidas
    for (int i = 0; i < 14; i++) {
      _particles.add(_Particle.random(_rng, age: _rng.nextDouble()));
    }
    widget.controller.addListener(_tick);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    setState(() {
      // Actualizar cada partícula
      for (final p in _particles) {
        p.update(0.016); // ~60fps delta
      }
      // Reemplazar partículas muertas
      _particles.removeWhere((p) => p.isDead);
      while (_particles.length < _maxParticles) {
        _particles.add(_Particle.random(_rng));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _ParticlePainter(_particles),
    );
  }
}

class _Particle {
  double x; // fracción 0..1 del ancho
  double y; // fracción 0..1 del alto
  double vx; // velocidad horizontal
  double vy; // velocidad vertical (negativa = sube)
  double size;
  double age; // 0 = nace, 1 = muere
  double lifeSpeed; // qué tan rápido envejece
  final Color color;

  _Particle({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    required this.size,
    required this.age,
    required this.lifeSpeed,
    required this.color,
  });

  factory _Particle.random(math.Random rng, {double? age}) {
    final colors = [
      AppColors.primary,
      const Color(0xFF7C3AED),
      AppColors.primaryLight,
      AppColors.accent,
    ];
    return _Particle(
      x: rng.nextDouble(),
      y: rng.nextDouble(),
      vx: (rng.nextDouble() - 0.5) * 0.0006,
      vy: -(0.0003 + rng.nextDouble() * 0.0005), // siempre sube
      size: 1.5 + rng.nextDouble() * 3.0,
      age: age ?? 0.0,
      lifeSpeed: 0.003 + rng.nextDouble() * 0.004,
      color: colors[rng.nextInt(colors.length)],
    );
  }

  void update(double dt) {
    x += vx;
    y += vy;
    age += lifeSpeed;
    // wrap horizontal
    if (x < 0) x += 1;
    if (x > 1) x -= 1;
  }

  bool get isDead => age >= 1.0 || y < -0.02;

  // Opacidad: fade-in rápido (0→0.3), plateau, fade-out lento hacia el final
  double get opacity {
    if (age < 0.1) return age / 0.1 * 0.55;
    if (age > 0.75) return (1 - age) / 0.25 * 0.55;
    return 0.55;
  }
}

class _ParticlePainter extends CustomPainter {
  final List<_Particle> particles;
  _ParticlePainter(this.particles);

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in particles) {
      final paint = Paint()
        ..color = p.color.withOpacity(p.opacity * 0.65);
      canvas.drawCircle(
        Offset(p.x * size.width, p.y * size.height),
        p.size,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => true;
}
