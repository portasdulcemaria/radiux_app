import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';

/// Servicio singleton para feedback de audio clínico.
/// Cada sonido crea un AudioPlayer nuevo para evitar problemas de estado en iOS.
class SoundService {
  SoundService._();
  static final SoundService instance = SoundService._();

  bool _enabled = true;
  bool get enabled => _enabled;
  set enabled(bool v) => _enabled = v;

  // Configurar la sesión de audio al iniciar (necesario en iOS)
  Future<void> init() async {
    try {
      await AudioPlayer.global.setAudioContext(
        const AudioContext(
          iOS: AudioContextIOS(
            category: AVAudioSessionCategory.ambient, // no interrumpe música
            options: {
              AVAudioSessionOptions.mixWithOthers,
            },
          ),
          android: AudioContextAndroid(
            isSpeakerphoneOn: false,
            stayAwake: false,
            contentType: AndroidContentType.sonification,
            usageType: AndroidUsageType.assistanceSonification,
            audioFocus: AndroidAudioFocus.none,
          ),
        ),
      );
    } catch (e) {
      debugPrint('[SoundService] init error: $e');
    }
  }

  /// Tick suave: selecciones, confirmaciones, swap.
  Future<void> tick() => _play('tick');

  /// Chime doble: resultado calculado con éxito.
  Future<void> success() => _play('success');

  /// Tono bajo: error de validación.
  Future<void> error() => _play('error');

  Future<void> _play(String name) async {
    if (!_enabled) return;
    try {
      // Crear un player nuevo cada vez — más confiable en iOS
      final player = AudioPlayer();
      await player.setVolume(0.7);
      await player.play(AssetSource('sounds/$name.wav'));
      // Liberar el player cuando termine
      player.onPlayerComplete.listen((_) => player.dispose());
    } catch (e) {
      debugPrint('[SoundService] play($name) error: $e');
    }
  }
}
