import 'dart:math' as math;
import 'unit.dart';

class DecayService {
  /// A(t) = A₀ × 2^(−t/T½)
  static double decay({
    required double initialActivity,
    required double halfLifeHours,
    required double elapsedHours,
  }) {
    if (halfLifeHours <= 0) return initialActivity;
    if (elapsedHours < 0) return initialActivity;
    return initialActivity * math.pow(2, -elapsedHours / halfLifeHours);
  }

  static double decayFraction({
    required double halfLifeHours,
    required double elapsedHours,
  }) {
    return math.pow(2, -elapsedHours / halfLifeHours).toDouble();
  }

  /// Percentage remaining
  static double percentRemaining({
    required double halfLifeHours,
    required double elapsedHours,
  }) {
    return decayFraction(halfLifeHours: halfLifeHours, elapsedHours: elapsedHours) * 100;
  }

  static double convert(double value, RadioUnit from, RadioUnit to) {
    final inMBq = value * from.toMBq;
    return inMBq / to.toMBq;
  }

  /// Smart format: avoid too many or too few decimals
  static String formatActivity(double value) {
    if (value == 0) return '0';
    final abs = value.abs();
    if (abs >= 1e9) {
      return '${(value / 1e9).toStringAsFixed(4)} × 10⁹';
    } else if (abs >= 1e6) {
      return (value / 1e6).toStringAsFixed(4) + ' × 10⁶';
    } else if (abs >= 10000) {
      return value.toStringAsFixed(2);
    } else if (abs >= 100) {
      return value.toStringAsFixed(4);
    } else if (abs >= 1) {
      return value.toStringAsFixed(6);
    } else if (abs >= 0.001) {
      return value.toStringAsFixed(8);
    } else {
      return value.toStringAsExponential(4);
    }
  }
}
