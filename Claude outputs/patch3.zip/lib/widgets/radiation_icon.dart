import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Ícono ☢ dibujado con CustomPainter.
/// Soporta glow animable vía [glowColor] y [glowBlur].
class RadiationIcon extends StatelessWidget {
  final double size;
  final Color color;
  final Color? glowColor;
  final double glowBlur;

  const RadiationIcon({
    super.key,
    this.size = 24,
    required this.color,
    this.glowColor,
    this.glowBlur = 0,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _RadiationPainter(
          color: color,
          glowColor: glowColor,
          glowBlur: glowBlur,
        ),
      ),
    );
  }
}

class _RadiationPainter extends CustomPainter {
  final Color color;
  final Color? glowColor;
  final double glowBlur;

  _RadiationPainter({
    required this.color,
    this.glowColor,
    this.glowBlur = 0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r = size.width / 2;

    // Glow layer
    if (glowColor != null && glowBlur > 0) {
      final glowPaint = Paint()
        ..color = glowColor!
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, glowBlur);
      _drawSymbol(canvas, cx, cy, r, glowPaint);
    }

    // Main layer
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;
    _drawSymbol(canvas, cx, cy, r, paint);
  }

  void _drawSymbol(Canvas canvas, double cx, double cy, double r, Paint paint) {
    // Centro sólido
    final innerR = r * 0.18;
    final outerR = r * 0.50;
    final bladeInner = r * 0.22;
    final bladeOuter = r * 0.92;

    // Núcleo
    canvas.drawCircle(Offset(cx, cy), innerR, paint);

    // 3 aspas a 120° cada una (símbolo estándar de radiación)
    for (int i = 0; i < 3; i++) {
      final angle = (i * 120 - 90) * math.pi / 180;
      final path = Path();

      // Arco interior
      final innerRect = Rect.fromCircle(
        center: Offset(cx, cy),
        radius: bladeInner,
      );
      // Arco exterior
      final outerRect = Rect.fromCircle(
        center: Offset(cx, cy),
        radius: bladeOuter,
      );

      const sweep = 55 * math.pi / 180; // ancho del aspa en radianes

      path.addArc(innerRect, angle - sweep / 2, sweep);
      path.arcTo(outerRect, angle + sweep / 2, -sweep, false);
      path.close();

      canvas.drawPath(path, paint);
    }

    // Anillo hueco entre núcleo y aspas (blanco/transparente para cortar)
    final ringPaint = Paint()
      ..color = Colors.transparent
      ..blendMode = BlendMode.clear;
    // No necesitamos cortar — el aspa empieza en bladeInner que ya deja espacio

    // Círculo exterior (borde opcional, lo omitimos para look minimalista)
  }

  @override
  bool shouldRepaint(_RadiationPainter old) =>
      old.color != color ||
      old.glowColor != glowColor ||
      old.glowBlur != glowBlur;
}
