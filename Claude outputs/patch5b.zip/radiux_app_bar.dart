import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class RadiuxAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;
  final bool showMenuButton;

  const RadiuxAppBar({
    super.key,
    required this.title,
    this.actions,
    this.showMenuButton = true,
  });

  @override
  Size get preferredSize => const Size.fromHeight(56);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.surface,
      child: SafeArea(
        bottom: false,
        child: Container(
          height: 56,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          decoration: const BoxDecoration(
            border: Border(bottom: BorderSide(color: AppColors.border, width: 0.5)),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Hamburger a la izquierda
              if (showMenuButton)
                Align(
                  alignment: Alignment.centerLeft,
                  child: _BurgerButton(onTap: () => Scaffold.of(context).openDrawer()),
                ),
              // "Radiux" centrado — solo texto
              RichText(
                text: const TextSpan(
                  children: [
                    TextSpan(
                      text: 'Radi',
                      style: TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.5,
                      ),
                    ),
                    TextSpan(
                      text: 'ux',
                      style: TextStyle(
                        color: AppColors.primary,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -0.5,
                      ),
                    ),
                  ],
                ),
              ),
              // Acciones a la derecha
              if (actions != null)
                Align(
                  alignment: Alignment.centerRight,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [...actions!, const SizedBox(width: 4)],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Burger premium: 3 líneas con ancho decreciente (16 / 12 / 8)
class _BurgerButton extends StatelessWidget {
  final VoidCallback onTap;
  const _BurgerButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          width: 40,
          height: 40,
          alignment: Alignment.center,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Line(width: 18),
              const SizedBox(height: 5),
              _Line(width: 18),
              const SizedBox(height: 5),
              _Line(width: 18),
            ],
          ),
        ),
      ),
    );
  }
}

class _Line extends StatelessWidget {
  final double width;
  const _Line({required this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: 2,
      decoration: BoxDecoration(
        color: AppColors.textPrimary,
        borderRadius: BorderRadius.circular(1),
      ),
    );
  }
}
