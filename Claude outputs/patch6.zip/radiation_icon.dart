import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Ícono ☢ dibujado con CustomPainter — versión outline delicada.
/// Trazo fino: anillo exterior + núcleo + 3 aspas como trazos.
/// Soporta glow animable vía [glowColor] y [glowBlur].
class RadiationIcon extends StatelessWidget {
  final double size;
  final Color color;
  final Color? glowColor;
  final double glowBlur;

  const RadiationIcon({
    super.key,
    this.size = 24,
    required this.color,
    this.glowColor,
    this.glowBlur = 0,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _RadiationPainter(
          color: color,
          glowColor: glowColor,
          glowBlur: glowBlur,
        ),
      ),
    );
  }
}

class _RadiationPainter extends CustomPainter {
  final Color color;
  final Color? glowColor;
  final double glowBlur;

  _RadiationPainter({
    required this.color,
    this.glowColor,
    this.glowBlur = 0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r = size.width / 2;
    final stroke = r * 0.095; // grosor del trazo — muy fino

    if (glowColor != null && glowBlur > 0) {
      final glow = Paint()
        ..color = glowColor!
        ..style = PaintingStyle.stroke
        ..strokeWidth = stroke
        ..strokeCap = StrokeCap.round
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, glowBlur);
      _drawOutline(canvas, cx, cy, r, stroke, glow);
    }

    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round;

    _drawOutline(canvas, cx, cy, r, stroke, paint);
  }

  void _drawOutline(
      Canvas canvas, double cx, double cy, double r, double stroke, Paint p) {
    // Radios clave
    final coreR = r * 0.17;       // núcleo central
    final gapInner = r * 0.26;    // inicio de las aspas
    final gapOuter = r * 0.72;    // fin de las aspas
    final ringR = r * 0.88;       // anillo exterior

    // ── Anillo exterior ──────────────────────────────────────
    canvas.drawCircle(Offset(cx, cy), ringR, p);

    // ── Núcleo central ───────────────────────────────────────
    canvas.drawCircle(Offset(cx, cy), coreR, p);

    // ── 3 aspas como arcos gruesos ───────────────────────────
    const sweepDeg = 52.0; // ancho angular de cada aspa
    const sweep = sweepDeg * math.pi / 180;

    final bladePaint = Paint()
      ..color = p.color
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke * 5.5  // aspas más anchas que el contorno
      ..strokeCap = StrokeCap.round
      ..maskFilter = p.maskFilter;

    final bladeRect = Rect.fromCircle(
      center: Offset(cx, cy),
      radius: (gapInner + gapOuter) / 2,
    );
    final bladeStrokeR = (gapOuter - gapInner) / 2;
    // Las aspas son arcos cuyo strokeWidth cubre la banda entre gapInner y gapOuter
    final arcPaint = Paint()
      ..color = p.color
      ..style = PaintingStyle.stroke
      ..strokeWidth = bladeStrokeR * 2
      ..strokeCap = StrokeCap.butt
      ..maskFilter = p.maskFilter;

    for (int i = 0; i < 3; i++) {
      final startAngle = (i * 120 - 90 - sweepDeg / 2) * math.pi / 180;
      canvas.drawArc(bladeRect, startAngle, sweep, false, arcPaint);
    }
  }

  @override
  bool shouldRepaint(_RadiationPainter old) =>
      old.color != color ||
      old.glowColor != glowColor ||
      old.glowBlur != glowBlur;
}
