import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Vercel-style glassmorphism card with animated gradient border
class GlassCard extends StatefulWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double borderRadius;
  final bool hasBorderGlow;
  final Color? glowColor;
  final bool isActive;

  const GlassCard({
    super.key,
    required this.child,
    this.padding,
    this.borderRadius = 16,
    this.hasBorderGlow = false,
    this.glowColor,
    this.isActive = false,
  });

  @override
  State<GlassCard> createState() => _GlassCardState();
}

class _GlassCardState extends State<GlassCard> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final glow = widget.glowColor ?? AppColors.primary;
    final br = BorderRadius.circular(widget.borderRadius);

    return AnimatedBuilder(
      animation: _controller,
      builder: (_, child) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: br,
            boxShadow: widget.hasBorderGlow || widget.isActive
                ? [
                    BoxShadow(
                      color: glow.withOpacity(0.18 + 0.08 * _controller.value),
                      blurRadius: 16 + 8 * _controller.value,
                      spreadRadius: 0,
                    ),
                  ]
                : null,
          ),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: br,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppColors.card.withOpacity(0.97),
                  AppColors.surface.withOpacity(0.93),
                ],
              ),
              border: Border.all(
                color: widget.isActive
                    ? glow.withOpacity(0.5 + 0.2 * _controller.value)
                    : AppColors.border.withOpacity(0.6),
                width: widget.isActive ? 1.5 : 0.8,
              ),
            ),
            child: child,
          ),
        );
      },
      child: Padding(
        padding: widget.padding ?? const EdgeInsets.all(16),
        child: widget.child,
      ),
    );
  }
}

/// Vercel-style gradient border button
class GradientBorderButton extends StatefulWidget {
  final String label;
  final VoidCallback? onTap;
  final bool isLoading;
  final Widget? icon;

  const GradientBorderButton({
    super.key,
    required this.label,
    this.onTap,
    this.isLoading = false,
    this.icon,
  });

  @override
  State<GradientBorderButton> createState() => _GradientBorderButtonState();
}

class _GradientBorderButtonState extends State<GradientBorderButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null && !widget.isLoading;

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled ? (_) => setState(() => _pressed = false) : null,
      onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
      onTap: enabled ? widget.onTap : null,
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: AnimatedBuilder(
          animation: _pulse,
          builder: (_, child) {
            return Container(
              height: 54,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: enabled
                    ? LinearGradient(
                        begin: Alignment(
                          -1 + 2 * _pulse.value,
                          -1 + 2 * _pulse.value,
                        ),
                        colors: const [
                          AppColors.primaryDark,
                          AppColors.primary,
                          AppColors.primaryLight,
                        ],
                      )
                    : null,
                color: enabled ? null : AppColors.card,
                boxShadow: enabled
                    ? [
                        BoxShadow(
                          color: AppColors.primary.withOpacity(0.3 + 0.1 * _pulse.value),
                          blurRadius: 16,
                          offset: const Offset(0, 4),
                        ),
                      ]
                    : null,
              ),
              child: child,
            );
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (widget.isLoading)
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              else if (widget.icon != null) ...[
                widget.icon!,
                const SizedBox(width: 8),
              ],
              Text(
                widget.label,
                style: TextStyle(
                  color: widget.onTap != null ? Colors.white : AppColors.textDisabled,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Animated result card with glow reveal
class ResultCard extends StatelessWidget {
  final String value;
  final String unit;
  final String? label;
  final Color? glowColor;
  final VoidCallback? onCopy;

  const ResultCard({
    super.key,
    required this.value,
    required this.unit,
    this.label,
    this.glowColor,
    this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    final glow = glowColor ?? AppColors.accent;
    return GlassCard(
      hasBorderGlow: true,
      glowColor: glow,
      isActive: true,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (label != null) ...[
            Text(
              label!,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                color: glow.withOpacity(0.8),
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 8),
          ],
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Text(
                  value,
                  style: Theme.of(context).textTheme.displayMedium?.copyWith(
                    color: AppColors.textPrimary,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  unit,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: glow,
                  ),
                ),
              ),
            ],
          ),
          if (onCopy != null) ...[
            const SizedBox(height: 12),
            GestureDetector(
              onTap: onCopy,
              child: Row(
                children: [
                  Icon(Icons.copy_rounded, size: 14, color: AppColors.textSecondary),
                  const SizedBox(width: 6),
                  Text(
                    'Copiar resultado',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
